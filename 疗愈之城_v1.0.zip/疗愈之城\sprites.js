/* 角色、记忆痕迹、光照、排序绘制与主循环。 */

function drawPerson(ctx, wx, wy, opt = {}) {
  const [sx, sy] = P(wx, wy);
  const s = opt.scale || 1;
  const moving = Boolean(opt.moving);
  const walk = opt.walk || 0;
  const phase = opt.phase || 0;
  const swing = moving ? Math.sin(walk) * 2.4 : 0;
  const bob = moving ? Math.abs(Math.sin(walk)) * 1.4 : Math.sin(G.time * 1.8 + phase) * 0.7;
  const dir = opt.dir || "down";
  const coat = opt.coat || "#e7dbc9";
  const coatShade = opt.coatShade || "#c9b79f";
  const pants = opt.pants || "#4e4b46";
  const skin = opt.skin || "#eac0a0";
  const hair = opt.hair || "#3c2d25";

  ctx.beginPath();
  ctx.ellipse(sx, sy, 16 * s, 5.5 * s, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(30,22,16,.24)";
  ctx.fill();

  ctx.save();
  ctx.translate(sx, sy);

  // 腿
  ctx.fillStyle = pants;
  rrect(ctx, -7.5 * s + swing, -17 * s, 6 * s, 17 * s, 2.6 * s);
  ctx.fill();
  rrect(ctx, 1.5 * s - swing, -17 * s, 6 * s, 17 * s, 2.6 * s);
  ctx.fill();

  // 身体
  ctx.beginPath();
  ctx.moveTo(-11.5 * s, -45 * s + bob);
  ctx.quadraticCurveTo(0, -49 * s + bob, 11.5 * s, -45 * s + bob);
  ctx.lineTo(10 * s, -14 * s + bob);
  ctx.quadraticCurveTo(0, -11 * s + bob, -10 * s, -14 * s + bob);
  ctx.closePath();
  ctx.fillStyle = coat;
  ctx.fill();
  ctx.strokeStyle = "rgba(60,42,30,.18)";
  ctx.lineWidth = 1;
  ctx.stroke();

  // 衣服色块
  ctx.beginPath();
  ctx.moveTo(-10 * s, -32 * s + bob);
  ctx.lineTo(10 * s, -32 * s + bob);
  ctx.lineTo(9 * s, -15 * s + bob);
  ctx.lineTo(-9 * s, -15 * s + bob);
  ctx.closePath();
  ctx.fillStyle = opt.band || "rgba(149,171,143,.35)";
  ctx.fill();

  // 手臂
  ctx.strokeStyle = coatShade;
  ctx.lineWidth = 5 * s;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-10 * s, -38 * s + bob);
  ctx.lineTo(-14 * s - swing * 0.4, -22 * s + bob);
  ctx.moveTo(10 * s, -38 * s + bob);
  ctx.lineTo(14 * s + swing * 0.4, -22 * s + bob);
  ctx.stroke();

  // 头
  const headY = -56 * s + bob;
  ctx.beginPath();
  ctx.arc(0, headY, 10 * s, 0, Math.PI * 2);
  ctx.fillStyle = skin;
  ctx.fill();

  // 头发
  ctx.fillStyle = hair;
  if (dir === "up") {
    ctx.beginPath();
    ctx.arc(0, headY - 1 * s, 10.2 * s, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.beginPath();
    ctx.arc(0, headY - 2 * s, 10.2 * s, Math.PI * 0.94, Math.PI * 2.06);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(-10.4 * s, headY - 2 * s);
    ctx.quadraticCurveTo(0, headY - 7 * s, 10.4 * s, headY - 2 * s);
    ctx.lineTo(10.4 * s, headY + 2 * s);
    ctx.quadraticCurveTo(0, headY - 1 * s, -10.4 * s, headY + 2 * s);
    ctx.closePath();
    ctx.fill();
  }

  // 五官
  if (dir === "down" || dir === "left" || dir === "right") {
    const eyeOffset = dir === "left" ? -3.2 * s : dir === "right" ? 3.2 * s : 0;
    ctx.fillStyle = "rgba(46,32,26,.82)";
    if (dir === "down") {
      ctx.beginPath();
      ctx.arc(-3.4 * s + eyeOffset, headY + 1 * s, 1.15 * s, 0, Math.PI * 2);
      ctx.arc(3.4 * s + eyeOffset, headY + 1 * s, 1.15 * s, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.beginPath();
      ctx.arc(eyeOffset, headY + 1 * s, 1.15 * s, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = "rgba(150,90,72,.5)";
    ctx.lineWidth = 0.8 * s;
    ctx.beginPath();
    ctx.moveTo(eyeOffset - 1.3 * s, headY + 5 * s);
    ctx.quadraticCurveTo(eyeOffset, headY + 5.9 * s, eyeOffset + 1.3 * s, headY + 5 * s);
    ctx.stroke();
  }

  // 围巾 / 背包
  if (opt.scarf) {
    ctx.fillStyle = opt.scarf;
    rrect(ctx, -8 * s, -47 * s + bob, 16 * s, 4 * s, 2 * s);
    ctx.fill();
    ctx.fillRect(2 * s, -45 * s + bob, 3.4 * s, 12 * s);
  }
  if (opt.backpack) {
    ctx.fillStyle = "#546c5d";
    rrect(ctx, -8.5 * s, -40 * s + bob, 17 * s, 22 * s, 5 * s);
    ctx.fill();
    ctx.strokeStyle = "rgba(214,198,168,.5)";
    ctx.lineWidth = 1.1 * s;
    ctx.beginPath();
    ctx.moveTo(-6 * s, -35 * s + bob);
    ctx.lineTo(6 * s, -35 * s + bob);
    ctx.stroke();
  }

  ctx.restore();
}

function drawNameTag(ctx, wx, wy, text, opt = {}) {
  const [sx, sy] = P(wx, wy);
  const y = sy - (opt.offset || 76);
  ctx.save();
  ctx.font = '600 11px "PingFang SC","Microsoft YaHei",sans-serif';
  const tw = ctx.measureText(text).width;
  rrect(ctx, sx - tw / 2 - 9, y - 9, tw + 18, 19, 9);
  ctx.fillStyle = opt.bg || "rgba(26,21,18,.78)";
  ctx.fill();
  ctx.strokeStyle = opt.stroke || "rgba(255,240,220,.14)";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = opt.color || "#f0e2d2";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, sx, y + 0.5);
  ctx.restore();
}

function drawQuestMark(ctx, wx, wy, opt = {}) {
  const [sx, sy] = P(wx, wy);
  const bob = Math.sin(G.time * 3) * 3;
  const y = sy - (opt.offset || 112) + bob;
  ctx.save();
  ctx.beginPath();
  ctx.arc(sx, y, 10, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(232,165,110,.92)";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(sx, y, 14, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(232,165,110,.28)";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.fillStyle = "#2a1d13";
  ctx.font = '700 12px "PingFang SC","Microsoft YaHei",sans-serif';
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("!", sx, y + 0.5);
  ctx.restore();
}

function drawMemoryOrb(ctx, m) {
  const [sx, sy] = P(m.x, m.y, 0.35);
  const bob = Math.sin(G.time * 2.4 + m.x) * 4;
  const y = sy - 18 + bob;
  const r = 15;
  const grad = ctx.createRadialGradient(sx, y, 2, sx, y, 38);
  grad.addColorStop(0, "rgba(255,226,184,.65)");
  grad.addColorStop(0.55, "rgba(232,165,110,.2)");
  grad.addColorStop(1, "rgba(232,165,110,0)");
  ctx.beginPath();
  ctx.arc(sx, y, 38, 0, Math.PI * 2);
  ctx.fillStyle = grad;
  ctx.fill();

  ctx.beginPath();
  ctx.arc(sx, y, r, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(30,24,19,.76)";
  ctx.fill();
  ctx.strokeStyle = "rgba(248,213,165,.85)";
  ctx.lineWidth = 1.6;
  ctx.stroke();

  ctx.fillStyle = "#f6dfbc";
  ctx.font = '600 12px "Songti SC","Microsoft YaHei",serif';
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(m.glyph, sx, y + 0.5);

  ctx.beginPath();
  ctx.moveTo(sx, y + 20 + bob);
  ctx.lineTo(sx, sy - 2);
  ctx.strokeStyle = "rgba(248,213,165,.22)";
  ctx.lineWidth = 1;
  ctx.stroke();
}

function drawActorsAndProps(ctx) {
  const items = [];
  (G.map.props || []).forEach((p) => {
    const depth = (p.x || 0) + (p.w || 1) / 2 + (p.y || 0) + (p.d || 1) / 2 + (p.type === "pendant" ? 0.4 : 0);
    items.push({ depth, draw: () => drawProp(ctx, p) });
  });

  (G.map.npcs || []).forEach((n) => {
    items.push({
      depth: n.x + n.y,
      draw: () => {
        drawPerson(ctx, n.x, n.y, {
          scale: n.kid ? 0.88 : 0.96,
          dir: n.dir || "down",
          coat: n.kid ? "#8fa084" : "#d9cdb9",
          coatShade: n.kid ? "#71866f" : "#b8a790",
          pants: n.kid ? "#5d6456" : "#4d4a45",
          hair: n.kid ? "#40302a" : "#3a2c24",
          scarf: n.kid ? "" : "#778a72",
          backpack: n.kid,
          phase: 2,
        });
        drawNameTag(ctx, n.x, n.y, n.name, { offset: 80 });
        if (n.id === "xiaoyou" && !G.state.completed) {
          drawQuestMark(ctx, n.x, n.y, { offset: 104 });
        }
      },
    });
  });

  items.push({
    depth: G.player.x + G.player.y + 0.05,
    draw: () => {
      drawPerson(ctx, G.player.x, G.player.y, {
        scale: 0.98,
        dir: G.player.dir,
        coat: "#e9ddcb",
        coatShade: "#c8b59d",
        pants: "#4c4a45",
        scarf: "#7b8e76",
        moving: G.player.moving,
        walk: G.player.walk,
        phase: 0,
      });
    },
  });

  if (G.state.phase === "night" && G.state.step === 5) {
    (G.map.memories || []).forEach((m) => {
      if (G.state.memories.includes(m.id)) return;
      items.push({ depth: m.x + m.y + 0.2, draw: () => drawMemoryOrb(ctx, m) });
    });
  }

  items.sort((a, b) => a.depth - b.depth);
  items.forEach((it) => it.draw());
}

function drawLighting(ctx) {
  const phase = G.state.phase;
  ctx.save();
  if (phase === "night") {
    ctx.fillStyle = "rgba(11,15,30,.5)";
    ctx.fillRect(0, 0, G.vw, G.vh);
  } else if (phase === "day2") {
    ctx.fillStyle = "rgba(255,214,166,.035)";
    ctx.fillRect(0, 0, G.vw, G.vh);
  }
  ctx.restore();

  if (phase !== "night") return;

  ctx.save();
  ctx.translate(-G.camera.x, -G.camera.y);
  ctx.globalCompositeOperation = "lighter";
  (G.map.lights || []).forEach((l) => {
    const [sx, sy] = P(l.x, l.y, l.z || 1);
    const grad = ctx.createRadialGradient(sx, sy, 4, sx, sy, l.r);
    grad.addColorStop(0, l.color || "rgba(255,196,132,.28)");
    grad.addColorStop(1, "rgba(255,196,132,0)");
    ctx.beginPath();
    ctx.arc(sx, sy, l.r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();
  });

  if (G.state.step === 5) {
    (G.map.memories || []).forEach((m) => {
      if (G.state.memories.includes(m.id)) return;
      const [sx, sy] = P(m.x, m.y, 0.35);
      const grad = ctx.createRadialGradient(sx, sy - 18, 3, sx, sy - 18, 90);
      grad.addColorStop(0, "rgba(255,220,170,.3)");
      grad.addColorStop(1, "rgba(255,220,170,0)");
      ctx.beginPath();
      ctx.arc(sx, sy - 18, 90, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();
    });
  }
  ctx.restore();
}

function render() {
  const ctx = G.ctx;
  if (!ctx || !G.map) return;
  const map = G.map;
  const night = G.state.phase === "night";

  ctx.setTransform(G.dpr, 0, 0, G.dpr, 0, 0);
  const bg = ctx.createLinearGradient(0, 0, 0, G.vh);
  bg.addColorStop(0, night ? "#0d1220" : "#191410");
  bg.addColorStop(1, night ? "#151a26" : "#0f0c0a");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, G.vw, G.vh);

  ctx.save();
  ctx.translate(-G.camera.x, -G.camera.y);

  drawFloors(ctx);
  drawFloorDecals(ctx);
  drawWalls(ctx);
  drawBuildings(ctx);
  drawBorderWalls(ctx);
  drawActorsAndProps(ctx);

  ctx.restore();

  drawLighting(ctx);
}

function renderStatic() {
  render();
}

function clickableAt(sx, sy) {
  const list = visibleInteractables();
  let best = null;
  let bestDist = 54;
  const camX = G.camera.x;
  const camY = G.camera.y;
  list.forEach((it) => {
    const [ax, ay] = P(it.x, it.y, it.clickZ || 0.35);
    const d = Math.hypot(ax - (sx + camX), ay - (sy + camY));
    const limit = it.clickR || 56;
    if (d < limit && d < bestDist) {
      bestDist = d;
      best = it;
    }
  });
  return best;
}

let loopStarted = false;

function startLoop() {
  if (loopStarted) return;
  loopStarted = true;
  G.lastTs = performance.now();
  requestAnimationFrame(tick);
}

function tick(ts) {
  const dt = Math.min(0.045, Math.max(0, (ts - G.lastTs) / 1000 || 0));
  G.lastTs = ts;
  G.time += dt;
  updateMovement(dt);
  setCameraSmooth(dt);
  if (typeof updateInteractHint === "function") updateInteractHint();
  render();
  requestAnimationFrame(tick);
}
