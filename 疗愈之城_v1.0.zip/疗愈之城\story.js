/* 第一章剧情、任务链与场景交互。 */

const MEMORY_LINES = {
  candy: {
    scene: "便利店门口，玻璃罐里还剩几颗水果糖。糖纸被夜里的灯照得很亮。",
    quote: "她每次都会把水果糖分我一半。她说，甜的要一起尝才算数。",
  },
  umbrella: {
    scene: "公交站的长椅下面，靠着那把旧伞。伞骨有一处修过的痕迹。",
    quote: "下雨那天，我们挤在同一把伞下。她的半边肩膀都淋湿了，还一直说没事。",
  },
  book: {
    scene: "旧书店的台阶上，放着一本翻旧了的绘本，最后一页折了角。",
    quote: "那本绘本我们看了好多遍。她每次都抢着念最后一页，念得特别大声。",
  },
  photo: {
    scene: "长椅的缝隙里，压着一张没有撕掉的合照。边角已经发皱了。",
    quote: "春游那天拍的。我本来想撕掉的……可是到最后，还是没有。",
  },
};

function questData() {
  const s = G.state;
  const memDone = s.memories.length >= 4;
  const objectives = [
    { text: "听小友说明来意", done: s.step >= 2, active: s.step === 1 },
    { text: "用 AI 终端分析这份委托", done: s.step >= 3, active: s.step === 2 },
    { text: "结束营业，进入夜晚回访", done: s.step >= 4, active: s.step === 3 },
    { text: "听听她执行方案后的感受", done: s.step >= 5, active: s.step === 4 },
    { text: `在街区找回四段记忆（${s.memories.length} / 4）`, done: s.step >= 6, active: s.step === 5 },
    { text: "听她真正想要的，重新评估方案", done: s.step >= 6, active: false },
    { text: "结束这一夜，进入第二天", done: s.step >= 7, active: s.step === 6 },
    { text: "第二天，让她自己开口", done: s.step >= 8, active: s.step === 7 },
  ].map((o) => ({
    text: o.text,
    state: o.done ? "is-done" : o.active ? "is-active" : "",
  }));

  let hint = "";
  if (s.completed) hint = "委托已归档。可以在 AI 终端查看下一份委托，或继续在咖啡馆里走走。";
  else if (s.step === 1) hint = "走到窗边的小友身边，按 E 或点击她交谈。";
  else if (s.step === 2) hint = "走到 AI 终端前，按 E 分析这份委托。";
  else if (s.step === 3) hint = "走到玻璃门前，按 E 结束营业。";
  else if (s.step === 4) hint = "点击小友，听听她执行方案后的感受。";
  else if (s.step === 5) {
    hint = memDone
      ? "四段记忆都找回来了。回到咖啡馆和小友聊聊。"
      : "去街区走走。点击发光的记忆痕迹；也可以在门口按 E 出门。";
  } else if (s.step === 6) hint = "从玻璃门结束这一夜，进入第二天。";
  else if (s.step === 7) hint = "点击小友，听她准备怎么开口。";

  return { title: "那张没有撕掉的合照", objectives, hint };
}

function questTarget() {
  const s = G.state;
  if (!G.map || s.completed) return null;
  const npc = (G.map.npcs || []).find((n) => n.id === "xiaoyou");
  const findIt = (key) => (G.interactables || []).find((it) => it.story === key);
  const onStreet = G.mapId === "street";

  if (s.phase === "day1") {
    if (s.step === 1 && npc) return { x: npc.x, y: npc.y, range: 1.6, story: "xiaoyou", label: "小友" };
    if (s.step === 2) {
      const it = findIt("terminal");
      return it ? { x: it.x, y: it.y, range: 1.5, story: "terminal", label: "AI 终端" } : null;
    }
    if (s.step >= 3) {
      const it = findIt("cafeDoor");
      return it ? { x: it.x, y: it.y, range: 1.5, story: "cafeDoor", label: "玻璃门" } : null;
    }
  }

  if (s.phase === "night") {
    if (s.step === 4 && npc) return { x: npc.x, y: npc.y, range: 1.6, story: "xiaoyou", label: "小友" };
    if (s.step === 5) {
      if (onStreet) {
        const left = (G.map.memories || []).filter((m) => !s.memories.includes(m.id));
        if (!left.length) {
          const it = findIt("streetDoor");
          return it ? { x: it.x, y: it.y, range: 1.5, story: "streetDoor", label: "咖啡馆" } : null;
        }
        let best = null;
        let bd = Infinity;
        left.forEach((m) => {
          const d = Math.hypot(m.x - G.player.x, m.y - G.player.y);
          if (d < bd) {
            bd = d;
            best = m;
          }
        });
        return best
          ? { x: best.x, y: best.y, range: 1.5, story: "memory", memory: best, label: best.name }
          : null;
      }
      if (s.memories.length >= 4 && npc) {
        return { x: npc.x, y: npc.y, range: 1.6, story: "xiaoyou", label: "小友" };
      }
      const it = findIt("cafeDoor");
      return it ? { x: it.x, y: it.y, range: 1.5, story: "cafeDoor", label: "去街区" } : null;
    }
    if (s.step >= 6) {
      const doorKey = onStreet ? "streetDoor" : "cafeDoor";
      const it = findIt(doorKey);
      return it
        ? { x: it.x, y: it.y, range: 1.5, story: doorKey, label: onStreet ? "咖啡馆" : "玻璃门" }
        : null;
    }
  }

  if (s.phase === "day2" && s.step === 7 && npc) {
    return { x: npc.x, y: npc.y, range: 1.6, story: "xiaoyou", label: "小友" };
  }
  return null;
}

function goToQuest() {
  if (G.dialogOpen || G.panelOpen || G.titleOpen) return;
  const t = questTarget();
  if (!t) {
    toast("当前没有需要前往的目标。");
    return;
  }
  G.keys.clear();
  G.path = [];
  G.onArrive = null;
  toast(`正在前往 <strong>${t.label}</strong>…`);
  walkTo(t.x, t.y, t.range || 1.6, () => {
    if (t.story === "memory") runStory("memory", t);
    else if (t.story === "xiaoyou") runStory("xiaoyou");
    else runStory(t.story, t);
  });
}

function doorLabel() {
  const s = G.state;
  if (s.phase === "day1") return s.step >= 3 ? "玻璃门 · 结束营业" : "玻璃门";
  if (s.phase === "night") {
    if (s.step === 4) return "玻璃门";
    if (s.step === 5) return "玻璃门 · 去街区";
    if (s.step === 6) return "玻璃门 · 结束这一夜";
    return "玻璃门";
  }
  return "玻璃门";
}

function visibleInteractables() {
  if (!G.map) return [];
  const list = G.interactables.map((it) => {
    let label = "查看";
    let cz = 0.4;
    let clickR = 56;
    if (it.story === "cafeDoor") {
      label = doorLabel();
      cz = 0.72;
      clickR = 74;
    } else if (it.story === "streetDoor") {
      label = it.label || "回到咖啡馆";
      cz = 0.75;
      clickR = 72;
    } else if (it.story === "terminal") {
      label = "AI 终端";
      cz = 0.72;
      clickR = 64;
    } else if (it.story === "coffee") {
      label = "吧台 · 手冲一杯";
      cz = 0.55;
    } else if (it.story === "cat") {
      label = "窗边的猫";
      cz = 0.2;
    } else if (it.story === "paper") {
      label = "旧纸片";
      cz = 0.12;
    }
    return { ...it, label, clickZ: cz, clickR };
  });

  (G.map.npcs || []).forEach((n) => {
    list.push({
      story: n.id === "xiaoyou" ? "xiaoyou" : "npc",
      npc: n,
      x: n.x,
      y: n.y,
      range: 1.55,
      label: `和小友交谈`,
      clickZ: 0.55,
      clickR: 58,
    });
  });

  if (G.state.phase === "night" && G.state.step === 5) {
    (G.map.memories || []).forEach((m) => {
      if (G.state.memories.includes(m.id)) return;
      list.push({
        story: "memory",
        memory: m,
        x: m.x,
        y: m.y,
        range: 1.5,
        label: `拾起「${m.name}」`,
        clickZ: 0.9,
        clickR: 62,
      });
    });
  }

  return list;
}

function interactNearest() {
  if (!G.nearest) {
    toast("走近一点，再和它互动。");
    return;
  }
  const item = G.nearest;
  G.path = [];
  G.onArrive = null;
  runStory(item.story, item);
}

function runStory(key, item) {
  if (key === "cafeDoor") return storyCafeDoor();
  if (key === "streetDoor") return storyStreetDoor();
  if (key === "xiaoyou") return storyXiaoyou();
  if (key === "coffee") return storyCoffee();
  if (key === "terminal") return storyTerminal();
  if (key === "cat") return storyCat();
  if (key === "paper") return storyPaper();
  if (key === "memory") return storyMemory(item.memory);
}

/* ---------------- 门 ---------------- */

function storyCafeDoor() {
  const s = G.state;
  if (s.phase === "day1") {
    if (s.step < 3) {
      toast("还没到关门时间。先把小友的委托处理好。");
      return;
    }
    showDialogue("ai", "今天的营业可以结束了。夜晚回访即将开始。", [
      { label: "结束营业，进入夜晚", primary: true, action: () => { closeDialogue(); goNight(); } },
      { label: "再待一会儿", action: closeDialogue },
    ]);
    return;
  }
  if (s.phase === "night") {
    if (s.step === 4) {
      toast("先和小友聊聊今晚的事，再决定要不要出门。");
      return;
    }
    if (s.step === 5) {
      closeDialogue();
      travelTo("street", MAPS.street.spawn.x, MAPS.street.spawn.y, "down");
      return;
    }
    if (s.step === 6) {
      showDialogue("ai", "今晚可以结束了。明天上午，她会带着自己的答案回来。", [
        { label: "结束这一夜", primary: true, action: () => { closeDialogue(); goDay2(); } },
        { label: "再想想", action: closeDialogue },
      ]);
      return;
    }
    toast("今晚的事已经结束了。");
    return;
  }
  if (s.phase === "day2") {
    if (s.step === 7) {
      toast("先听听小友的选择。");
      return;
    }
    toast("这一段委托已经告一段落。可以在咖啡馆里继续走走。");
  }
}

function storyStreetDoor() {
  closeDialogue();
  const fade = document.getElementById("fade");
  if (fade) fade.classList.add("is-on");
  setTimeout(() => {
    loadMap("cafe", 11.3, 1.5, "down");
    if (fade) fade.classList.remove("is-on");
    renderStatic();
    const s = G.state;
    if (s.step === 5 && s.memories.length < 4) {
      toast(`还差 ${4 - s.memories.length} 段记忆。再和小友聊聊吧。`);
    } else {
      toast("<strong>回到咖啡馆</strong> 门上的风铃轻轻响了一声。");
    }
  }, 360);
}

function goNight() {
  const s = G.state;
  s.phase = "night";
  s.step = 4;
  s.doorHint = true;
  saveGame();
  updateHUD();
  toast("<strong>时间推进</strong> 天色暗了下来。咖啡馆只剩下窗边的一盏灯。");
  setTimeout(() => {
    showDialogue("ai", "夜晚回访开始。委托人还坐在窗边。", [
      { label: "去找小友", primary: true, action: closeDialogue },
    ]);
  }, 520);
}

function goDay2() {
  const s = G.state;
  s.phase = "day2";
  s.step = 7;
  saveGame();
  updateHUD();
  toast("<strong>第二天</strong> 小友带着自己的答案，回到了靠窗的位置。");
  setTimeout(() => {
    showDialogue("ai", "新的方案已经准备好。委托人想自己试着说一次。", [
      { label: "去见她", primary: true, action: closeDialogue },
    ]);
  }, 520);
}

/* ---------------- 小友 ---------------- */

function storyXiaoyou() {
  const s = G.state;
  if (s.completed) {
    showDialogue("narr", "小友准备回家了。她把杯子推回吧台，说下次还会来。", [
      { label: "重新体验这一段委托", primary: true, action: () => { closeDialogue(); resetGame(); } },
      { label: "在咖啡馆里继续走走", action: closeDialogue },
    ]);
    return;
  }
  if (s.phase === "day1") {
    if (s.step === 1) return firstTalk();
    if (s.step === 2) {
      showDialogue("小友", "我把事情都说了……你会帮我想办法吗？", [
        { label: "我先把情况交给 AI 看看", primary: true, action: closeDialogue },
        { label: "再陪你坐一会儿", action: () => showDialogue("小友", "好。……其实坐着就挺好的。", [{ label: "去 AI 终端", action: closeDialogue, primary: true }]) },
      ]);
      return;
    }
    showDialogue("小友", "那我等你消息。", [{ label: "好", action: closeDialogue }]);
    return;
  }

  if (s.phase === "night") {
    if (s.step === 4) return nightRegretTalk();
    if (s.step === 5) {
      if (s.memories.length < 4) {
        showDialogue("小友", `我有点不敢去。你能再帮我看看吗？还差 ${4 - s.memories.length} 段记忆。`, [
          { label: "我再去街区走走", primary: true, action: closeDialogue },
        ]);
        return;
      }
      return nightWishes();
    }
    if (s.step === 6) {
      showDialogue("小友", "我已经想好了。明天，我想自己跟她说。", [
        { label: "好，我陪着你", primary: true, action: closeDialogue },
      ]);
      return;
    }
  }

  if (s.phase === "day2") {
    if (s.step === 7) return day2Talk();
    showDialogue("小友", "谢谢你，让我自己想清楚。", [{ label: "再见", action: closeDialogue }]);
  }
}

function firstTalk() {
  showDialogue("小友", "你好……这里，可以帮人解决烦恼吗？", [
    { label: "先说说发生了什么。", primary: true, action: herStory },
    {
      label: "你想喝点什么？我先给你做一杯。",
      action: () =>
        showDialogue("小友", "不用啦……我不是来喝东西的。", [
          { label: "那，你遇到什么事了？", primary: true, action: herStory },
        ]),
    },
    {
      label: "不用急。先坐一会儿，想说的时候再说。",
      req: { attr: "empathy", value: 3 },
      action: () => {
        addQuality(8);
        G.state.flags.patient = true;
        showDialogue("小友", "……谢谢。那我慢慢说。", [
          { label: "我听着", primary: true, action: herStory },
        ]);
      },
    },
  ]);
}

function herStory() {
  showDialogue(
    "小友",
    "我有个朋友，性格特别开朗。以前我们玩得特别好。可是现在，每到下课她就跑过来拽我的胳膊，非要我陪她出去玩。我跟她说过，我有时候想一个人待着、看看书。可她觉得我是在生气，还会问我是不是讨厌她了。妈妈说，好朋友就应该永远不分开，不要总推开别人。我是不是……太奇怪了？",
    [
      {
        label: "你想要一点独处的空间，但也不想失去她。",
        req: { attr: "empathy", value: 2 },
        primary: true,
        action: () => {
          G.state.flags.understood = true;
          addQuality(15);
          showDialogue("小友", "对……就是这样。", [
            { label: "我大概明白了", primary: true, action: finishFirstTalk },
          ]);
        },
      },
      {
        label: "她一直来找你，是不是也怕被你丢下？",
        req: { attr: "insight", value: 2 },
        action: () => {
          G.state.flags.sawFear = true;
          addQuality(10);
          showDialogue("小友", "……我没想过。她好像真的很怕我不理她。", [
            { label: "我们一起想办法", primary: true, action: finishFirstTalk },
          ]);
        },
      },
      {
        label: "那就直接告诉她，别再来打扰你。",
        action: () => {
          G.state.flags.harsh = true;
          showDialogue("小友", "我说过呀……可她只会更难过。", [
            { label: "……对不起", primary: true, action: finishFirstTalk },
          ]);
        },
      },
    ]
  );
}

function finishFirstTalk() {
  const s = G.state;
  if (s.step < 2) {
    s.step = 2;
    addXp(40);
    addJournal(
      "第一份委托：那张没有撕掉的合照",
      "小友，10 岁。她想要一点独处的空间，又不想因此失去最好的朋友。她把这件事带到了解忧咖啡馆。"
    );
    saveGame();
    updateHUD();
    toast("<strong>目标更新</strong> 用 AI 终端分析这份委托。");
  }
  showDialogue("小友", "那我等你消息。", [
    { label: "去 AI 终端", primary: true, action: closeDialogue },
  ]);
}

/* ---------------- 夜晚 ---------------- */

function nightRegretTalk() {
  showDialogue(
    "小友",
    "我跟她说了……我不想再跟她做朋友了。她问我，以后是不是连话都不能说了。我说……对。",
    [
      {
        label: "你后悔了吗？",
        primary: true,
        action: () => {
          addQuality(5);
          nightRegret();
        },
      },
      {
        label: "先别急着评价自己。你当时一定也很难受。",
        req: { attr: "empathy", value: 2 },
        action: () => {
          G.state.flags.gentle = true;
          addQuality(10);
          nightRegret();
        },
      },
    ]
  );
}

function nightRegret() {
  showDialogue(
    "小友",
    "我不知道。可是以前，我们会一起放学，一起分糖吃，下雨的时候挤在同一把伞下。她还说，长大以后要跟我去同一个城市。如果我不跟她做朋友了，那些事是不是就都没意义了？",
    [
      {
        label: "那些回忆不会消失。我们去找回它们。",
        primary: true,
        action: startMemoryQuest,
      },
      {
        label: "结束一段关系，不代表过去是假的。你只是需要换一种方式。",
        req: { attr: "empathy", value: 3 },
        action: () => {
          addQuality(12);
          startMemoryQuest();
        },
      },
    ]
  );
}

function startMemoryQuest() {
  const s = G.state;
  if (s.step < 5) {
    s.step = 5;
    addXp(30);
    addJournal(
      "夜晚的街区",
      "她说不敢一个人回去看。那些东西还在南街的某个角落，等着被重新看见。"
    );
    saveGame();
    updateHUD();
    toast("<strong>目标更新</strong> 去南街，找回四段记忆。");
  }
  showDialogue(
    "小友",
    "我有点不敢去。你能不能……替我看看？",
    [{ label: "交给我", primary: true, action: closeDialogue }]
  );
}

function storyMemory(memory) {
  if (!memory) return;
  if (G.state.memories.includes(memory.id)) {
    toast("这段记忆已经收好了。");
    return;
  }
  const lines = MEMORY_LINES[memory.id];
  if (!lines) return;
  showDialogue("narr", lines.scene, [
    {
      label: "听听她记得的",
      primary: true,
      action: () =>
        showDialogue("小友", lines.quote, [
          {
            label: "收好这段记忆",
            primary: true,
            action: () => collectMemory(memory),
          },
        ]),
    },
  ]);
}

function collectMemory(memory) {
  if (!addMemory(memory.id)) return;
  addQuality(5);
  addXp(20);
  closeDialogue();
  toast(`<strong>记忆碎片</strong> ${memory.name} · ${G.state.memories.length} / 4`);
  updateHUD();
  saveGame();
  if (G.state.memories.length === 4) {
    addJournal(
      "四段记忆",
      "糖果、雨伞、绘本、合照。它们没有证明这段关系必须继续，只证明过去的快乐是真的。"
    );
    setTimeout(() => {
      showDialogue("ai", "四段记忆已归档。回到咖啡馆吧，她还在等你。", [
        { label: "回咖啡馆", primary: true, action: closeDialogue },
      ]);
    }, 420);
  }
}

function nightWishes() {
  showDialogue(
    "小友",
    "我希望可以有自己安静待着的时间。我也希望……有一天，我们还能像以前一样说说话。",
    [
      {
        label: "这两个愿望，并不一定冲突。",
        primary: true,
        action: () => {
          addQuality(10);
          newPlan();
        },
      },
      {
        label: "你不用现在就想好答案。先把自己照顾好。",
        req: { attr: "empathy", value: 3 },
        action: () => {
          addQuality(15);
          newPlan();
        },
      },
    ]
  );
}

function newPlan() {
  const s = G.state;
  if (s.step < 6) {
    s.step = 6;
    addXp(30);
    addJournal(
      "新方案",
      "表达独处需求，建立双方都能接受的社交边界；不要求立即和好，也不要求彻底断绝关系。是否继续这段关系，由她决定。"
    );
    saveGame();
    updateHUD();
  }
  showDialogue(
    "ai",
    "已生成新的方案：表达独处需求，建立双方都能接受的社交边界；不要求立即和好，也不要求彻底断绝关系。",
    [{ label: "知道了", primary: true, action: closeDialogue }]
  );
}

/* ---------------- 第二天 ---------------- */

function day2Talk() {
  showDialogue(
    "小友",
    "我会告诉她，有时候我想一个人待一会儿。我不是讨厌她，只是偶尔需要安静。但如果她愿意改，我还是想跟她说说话。",
    [
      { label: "按你自己的想法去做吧。", primary: true, action: () => confirmEnding(false) },
      {
        label: "要不要我陪你去？或者先帮你把话写下来。",
        req: { attr: "action", value: 3 },
        action: () => {
          addQuality(12);
          showDialogue("小友", "谢谢你。但这次，我想自己说。", [
            { label: "好", primary: true, action: () => confirmEnding(true) },
          ]);
        },
      },
      {
        label: "如果她不愿意改呢？",
        action: () =>
          showDialogue("小友", "那也没关系。我不用今天就决定以后会怎么样。", [
            { label: "按你自己的想法去做吧。", primary: true, action: () => confirmEnding(false) },
          ]),
      },
    ]
  );
}

function confirmEnding(independent) {
  if (independent) G.state.flags.independent = true;
  showDialogue("ai", "委托阶段性完成。尚无法确认双方关系最终是否恢复。", [
    {
      label: "不用确认。",
      primary: true,
      action: () =>
        showDialogue("you", "因为那是她自己的生活。我们能做的，是帮她找到面对问题的办法。", [
          { label: "结束本章", primary: true, action: completeChapter },
        ]),
    },
  ]);
}

function completeChapter() {
  const s = G.state;
  if (s.completed) return;
  s.completed = true;
  s.step = 8;
  addXp(100);
  addQuality(10);
  const tier =
    s.quality >= 45
      ? "她带着自己的答案离开。朋友是否接受，还不知道；但这一次，她没有把选择交给别人。"
      : s.quality >= 25
        ? "她把需要说清楚了。关系会走向哪里，还没有答案，但至少不再只有「断绝」或「忍耐」两种选项。"
        : "她试着说出了自己的需要。结果还看不清，但这一步是她自己迈出去的。";
  addJournal("委托归档", tier);
  s.journalNote = tier;
  saveGame();
  updateHUD();
  closeDialogue();
  toast("<strong>委托完成</strong> 记忆碎片已归档，新的手记已写入。");
  setTimeout(() => {
    showDialogue("ai", "本章结束。你可以继续在咖啡馆里走走，或在 AI 终端查看下一份委托。", [
      { label: "留在咖啡馆", primary: true, action: closeDialogue },
      { label: "重新体验这一段委托", action: () => { closeDialogue(); resetGame(); } },
    ]);
  }, 700);
}

/* ---------------- AI 终端 ---------------- */

function storyTerminal() {
  const s = G.state;
  if (s.step === 1) {
    showDialogue("ai", "委托信息不足。先去和窗边的小友谈谈。", [
      { label: "知道了", action: closeDialogue },
    ]);
    return;
  }
  if (s.step === 2) {
    showDialogue(
      "ai",
      "已读取委托记录。问题类型：同伴交往冲突，社交空间被侵占。初始方案：明确拒绝；若对方继续靠近，则终止交往。",
      [
        {
          label: "采纳这个方案。",
          primary: true,
          action: () => {
            s.plan = "harsh";
            adoptPlan("初始方案已执行。今晚我会回访委托人。");
          },
        },
        {
          label: "等等。她想要的，可能不是断绝，而是喘息。",
          req: { attr: "insight", value: 2 },
          action: () => {
            s.flags.corrected = true;
            addQuality(15);
            showDialogue(
              "ai",
              "修正：需要保留旧友谊的权重。调整后的方案：减少接触频率，必要时明确拒绝。",
              [{ label: "先这样执行", primary: true, action: () => { s.plan = "adjusted"; adoptPlan("调整后的方案已执行。今晚我会回访委托人。"); } }]
            );
          },
        },
      ]
    );
    return;
  }
  if (s.phase === "day1" && s.step === 3) {
    showDialogue("ai", "方案已执行。今晚我会回访委托人。", [
      { label: "知道了", primary: true, action: closeDialogue },
    ]);
    return;
  }
  if (s.phase === "night" && s.step >= 4 && s.step <= 5) {
    showDialogue("ai", "回访进行中。委托人正在窗边等你。", [
      { label: "去找她", primary: true, action: closeDialogue },
    ]);
    return;
  }
  if (s.step === 6) {
    showDialogue("ai", "新方案已生成：表达独处需求，建立可调节的社交边界。明天她会自己试着说一次。", [
      { label: "知道了", primary: true, action: closeDialogue },
    ]);
    return;
  }
  if (s.completed) {
    showDialogue(
      "ai",
      "本章委托已归档。下一份委托已接入：阿澈，21 岁，大三。问题类型：关系中的自我边界。状态：筹备中。",
      [
        { label: "第二章 · 敬请期待", primary: true, action: closeDialogue },
        { label: "回到咖啡馆", action: closeDialogue },
      ]
    );
    return;
  }
  showDialogue("ai", "当前没有新的委托信息。", [{ label: "知道了", action: closeDialogue }]);
}

function adoptPlan(line) {
  const s = G.state;
  if (s.step < 3) {
    s.step = 3;
    addXp(30);
    addJournal(
      "初始方案",
      "AI 建议：明确拒绝，必要时终止交往。方案已经执行，夜晚会进行回访。"
    );
    saveGame();
    updateHUD();
    toast("<strong>目标更新</strong> 结束营业，进入夜晚。");
  }
  showDialogue("ai", line, [
    { label: "结束营业，进入夜晚", primary: true, action: () => { closeDialogue(); goNight(); } },
    { label: "再等等", action: closeDialogue },
  ]);
}

/* ---------------- 其他互动 ---------------- */

function storyCoffee() {
  const s = G.state;
  if (!s.drinkMade) {
    s.drinkMade = true;
    giveItem("coffee");
    addQuality(5);
    addXp(15);
    saveGame();
    showDialogue("narr", "你磨豆、注水，等它慢慢滴完。咖啡的香气在小店里散开了一点。", [
      { label: "端起咖啡", primary: true, action: closeDialogue },
    ]);
    return;
  }
  if (hasItem("coffee")) {
    showDialogue("narr", "吧台上的杯子还温着。热水注进手冲壶，等下一杯慢慢滴完。", [
      { label: "继续", action: closeDialogue },
    ]);
    return;
  }
  showDialogue("narr", "杯子已经空了。壶里还剩一点温水。", [{ label: "继续", action: closeDialogue }]);
}

function storyCat() {
  const s = G.state;
  if (!s.flags.cat) {
    s.flags.cat = true;
    addQuality(5);
    addXp(10);
    addJournal("窗边的猫", "猫的项圈上挂着一枚旧挂件。和小友书包上的那一枚很像。");
    saveGame();
    updateHUD();
    toast("<strong>手记更新</strong> 你注意到了一枚旧挂件。");
  }
  showDialogue("narr", "猫在窗边睡着，尾巴偶尔扫一下。它并不介意你靠近。", [
    { label: "摸摸它", primary: true, action: closeDialogue },
    { label: "让它继续睡", action: closeDialogue },
  ]);
}

function storyPaper() {
  const s = G.state;
  if (!s.flags.paper) {
    s.flags.paper = true;
    giveItem("paper");
    addQuality(5);
    addXp(10);
    addJournal("旧纸片", "书架背后压着一张被撕掉一角的合照。背面有一行褪色的字：下次还要一起去。");
    saveGame();
    updateHUD();
    toast("<strong>发现线索</strong> 一张没有撕掉的合照。");
  }
  showDialogue("narr", "书架背后压着一张旧纸片。被撕掉的那一角，让画面空了一块。", [
    { label: "收进背包", primary: true, action: closeDialogue },
  ]);
}
