/* 界面层：HUD、对话、任务卡、面板、提示、环境音。 */

const $ = (id) => document.getElementById(id);

const UI = {
  dialogue: $("dialogue"),
  dlgGlyph: $("dlgGlyph"),
  dlgName: $("dlgName"),
  dlgRole: $("dlgRole"),
  dlgText: $("dlgText"),
  dlgOptions: $("dlgOptions"),
  toasts: $("toasts"),
  hint: $("interactHint"),
  hintLabel: $("hintLabel"),
  panel: $("panel"),
  panelTitle: $("panelTitle"),
  panelBody: $("panelBody"),
  questState: $("questState"),
  questTitle: $("questTitle"),
  questObjectives: $("questObjectives"),
  questHint: $("questHint"),
  levelText: $("levelText"),
  xpFill: $("xpFill"),
  xpText: $("xpText"),
  mapName: $("mapName"),
  clockText: $("clockText"),
  titleScreen: $("titleScreen"),
  origin: $("origin"),
  fade: $("fade"),
};

const SPEAKERS = {
  xiaoyou: { name: "小友", role: "委托人 · 10 岁", glyph: "友" },
  ai: { name: "AI 搭档", role: "解忧系统", glyph: "AI" },
  you: { name: "你", role: "解忧咖啡馆 · 店员", glyph: "你" },
  narr: { name: "旁白", role: "", glyph: "叙" },
};

const ORIGIN_NAMES = { empathy: "倾听者", insight: "观察者", action: "行动派" };
const PHASE_TEXT = { day1: "第 1 天 · 上午", night: "第 1 天 · 夜晚", day2: "第 2 天 · 上午" };

let dialogueOnClose = null;

function toast(message) {
  if (!UI.toasts) return;
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = message;
  UI.toasts.appendChild(el);
  setTimeout(() => {
    el.classList.add("is-out");
    setTimeout(() => el.remove(), 420);
  }, 3200);
}

function updateHUD() {
  const s = G.state;
  UI.levelText.textContent = `Lv.${s.level}`;
  const prog = levelProgress();
  UI.xpFill.style.width = `${prog.pct}%`;
  UI.xpText.textContent = prog.text;
  UI.mapName.textContent = G.map ? G.map.name : "疗愈之城";
  UI.clockText.textContent = PHASE_TEXT[s.phase] || "";

  UI.questState.textContent = s.completed ? "已归档" : "进行中";
  UI.questState.classList.toggle("is-done", s.completed);

  const goBtn = $("questGo");
  if (goBtn) {
    const target = typeof questTarget === "function" ? questTarget() : null;
    goBtn.disabled = !target;
    goBtn.textContent = target ? "前往" : s.completed ? "已归档" : "无目标";
    goBtn.title = target ? `自动走到${target.label || "目标"}` : "当前没有需要前往的目标";
  }

  const q = typeof questData === "function" ? questData() : null;
  if (q) {
    UI.questTitle.textContent = q.title;
    UI.questObjectives.innerHTML = q.objectives
      .map((o) => `<li class="${o.state}">${o.text}</li>`)
      .join("");
    UI.questHint.textContent = q.hint || "";
  }
}

function updateInteractHint() {
  if (!G.map || G.dialogOpen || G.panelOpen || G.titleOpen) {
    UI.hint.hidden = true;
    G.nearest = null;
    return;
  }
  const list = typeof visibleInteractables === "function" ? visibleInteractables() : [];
  let best = null;
  let bestDist = 1.8;
  list.forEach((it) => {
    const range = it.range || 1.5;
    const d = Math.hypot(it.x - G.player.x, it.y - G.player.y);
    if (d <= range && d < bestDist) {
      bestDist = d;
      best = it;
    }
  });
  G.nearest = best;
  if (best) {
    UI.hintLabel.textContent = best.label;
    UI.hint.hidden = false;
  } else {
    UI.hint.hidden = true;
  }
}

function showDialogue(speakerKey, text, options = [], onClose = null) {
  const speaker = SPEAKERS[speakerKey] || SPEAKERS.narr;
  dialogueOnClose = onClose;
  G.dialogOpen = true;
  G.path = [];
  G.onArrive = null;
  UI.dlgGlyph.textContent = speaker.glyph;
  UI.dlgName.textContent = speaker.name;
  UI.dlgRole.textContent = speaker.role;
  UI.dlgGlyph.style.background =
    speakerKey === "ai"
      ? "linear-gradient(150deg,#a8c5c0,#5b7d78)"
      : speakerKey === "xiaoyou"
        ? "linear-gradient(150deg,#b9c9a9,#77896c)"
        : speakerKey === "you"
          ? "linear-gradient(150deg,#e7cba6,#a67c52)"
          : "linear-gradient(150deg,#b9ab9b,#7d7267)";
  UI.dlgText.textContent = text;
  UI.dlgOptions.innerHTML = "";

  const finalOptions = options.length ? options : [{ label: "继续", action: closeDialogue }];
  finalOptions.forEach((opt, index) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "option-btn";
    if (opt.primary) btn.classList.add("is-primary");

    const reqMet = !opt.req || G.state.attrs[opt.req.attr] >= opt.req.value;
    if (!reqMet) btn.classList.add("is-locked");

    const num = document.createElement("span");
    num.className = "num";
    num.textContent = String(index + 1);
    btn.appendChild(num);

    const label = document.createElement("span");
    label.textContent = opt.label;
    btn.appendChild(label);

    if (opt.req) {
      const badge = document.createElement("span");
      badge.className = "req";
      badge.textContent = `${ATTR_DEFS[opt.req.attr].name} ${opt.req.value}`;
      btn.appendChild(badge);
    }

    btn.addEventListener("click", () => {
      if (!reqMet) {
        toast(`你的${ATTR_DEFS[opt.req.attr].name}还不足以这样说。`);
        return;
      }
      if (opt.action) opt.action();
      else closeDialogue();
    });
    UI.dlgOptions.appendChild(btn);
  });

  UI.dialogue.hidden = false;

  // 如果自动播放开着，续时下一句计时
  if (UI.dialogue.classList.contains("is-auto")) {
    const opts = UI.dlgOptions.querySelectorAll(".option-btn");
    const isRealChoice = opts.length > 1;
    if (isRealChoice) {
      toggleDialogueAuto(); // 遇到选项自动停
    } else {
      startAutoAdvance();
    }
  }
}

function bindDialogueKeys() {
  document.addEventListener("keydown", (event) => {
    if (!G.dialogOpen) return;
    if (event.key === "Enter") {
      const btns = UI.dlgOptions.querySelectorAll(".option-btn");
      const primary = UI.dlgOptions.querySelector(".option-btn.is-primary:not(.is-locked)") || btns[0];
      if (primary) {
        event.preventDefault();
        primary.click();
      }
      return;
    }
    const idx = Number(event.key);
    if (idx >= 1 && idx <= 9) {
      const btns = UI.dlgOptions.querySelectorAll(".option-btn");
      const btn = btns[idx - 1];
      if (btn) {
        event.preventDefault();
        btn.click();
      }
    }
  });
}

/* ---------------- 面板 ---------------- */

function openPanel(kind) {
  if (G.dialogOpen) return;
  G.panelOpen = true;
  G.keys.clear();
  G.path = [];
  const titles = { journal: "手记", char: "角色", bag: "背包" };
  UI.panelTitle.textContent = titles[kind] || "手记";
  UI.panelBody.innerHTML = buildPanel(kind);
  UI.panel.hidden = false;
  bindPanelActions(kind);
}

function closePanel() {
  UI.panel.hidden = true;
  G.panelOpen = false;
  updateHUD();
}

function buildPanel(kind) {
  if (kind === "char") return buildCharPanel();
  if (kind === "bag") return buildBagPanel();
  return buildJournalPanel();
}

function buildCharPanel() {
  const s = G.state;
  const rows = Object.keys(ATTR_DEFS)
    .map((key) => {
      const def = ATTR_DEFS[key];
      const val = s.attrs[key];
      return `
      <div class="attr-row">
        <span class="attr-glyph">${def.glyph}</span>
        <div class="attr-info">
          <strong>${def.name}</strong>
          <small>${def.desc}</small>
        </div>
        <span class="attr-value">${val}</span>
        <button class="attr-plus" data-attr="${key}" ${s.points > 0 && val < 5 ? "" : "disabled"}>+</button>
      </div>`;
    })
    .join("");

  return `
    <p class="panel-lead">你是解忧咖啡馆的店员。比起替人做决定，你更擅长陪他们把问题看清楚。</p>
    <div class="origin-info"><span>角色倾向</span><b>${ORIGIN_NAMES[s.origin] || "尚未选择"}</b></div>
    <div class="origin-info"><span>等级</span><b>Lv.${s.level} · ${s.xp} 经验</b></div>
    <div class="origin-info"><span>可分配属性点</span><b>${s.points}</b></div>
    <p class="panel-note">${s.points > 0 ? "点击属性右侧的 + 分配属性点。" : "完成委托目标可以获得经验，升级后获得属性点。"}</p>
    <h3 class="section-title">属性</h3>
    ${rows}
  `;
}

function buildBagPanel() {
  const s = G.state;
  const items = s.items.map((id) => ITEM_DB[id]).filter(Boolean);
  const grid = items.length
    ? `<div class="item-grid">${items
        .map(
          (it) => `
        <div class="item-card">
          <span class="item-glyph">${it.glyph}</span>
          <div><strong>${it.name}</strong><small>${it.desc}</small></div>
        </div>`
        )
        .join("")}</div>`
    : `<p class="empty-note">背包里还空着。和场景里的人或物品互动，也许会找到什么。</p>`;

  return `
    <p class="panel-lead">有些东西不能解决问题，但能在解决问题的时候，让人没那么孤单。</p>
    <h3 class="section-title">随身物品</h3>
    ${grid}
    <h3 class="section-title">记忆碎片</h3>
    ${
      s.memories.length
        ? `<div>${s.memories
            .map((id) => {
              const it = ITEM_DB[id];
              return `<span class="memory-tag">${it ? it.name : id}</span>`;
            })
            .join("")}</div>`
        : `<p class="empty-note">还没有找回过记忆碎片。</p>`
    }
  `;
}

function buildJournalPanel() {
  const s = G.state;
  const q = typeof questData === "function" ? questData() : null;
  const questLines = q
    ? q.objectives
        .map(
          (o) => `<div class="quest-line ${o.state}"><span class="mark">${
            o.state === "is-done" ? "已" : o.state === "is-active" ? "→" : "·"
          }</span><span>${o.text}</span></div>`
        )
        .join("")
    : "";

  const entries = s.journal.length
    ? s.journal
        .map(
          (j) => `<div class="journal-entry"><strong>${j.title}</strong><p>${j.text}</p></div>`
        )
        .join("")
    : `<p class="empty-note">手记还是空白。随着委托推进，这里会记下你看见的东西。</p>`;

  const restart = s.completed
    ? `<button class="restart-btn" id="restartBtn">重新体验这一段委托</button>`
    : "";

  return `
    <p class="panel-lead">「${q ? q.title : "那张没有撕掉的合照"}」 · ${
      s.completed ? "已归档" : "进行中"
    }</p>
    <h3 class="section-title">委托进度</h3>
    ${questLines}
    <h3 class="section-title">手记</h3>
    ${entries}
    ${restart}
  `;
}

function bindPanelActions(kind) {
  if (kind === "char") {
    UI.panelBody.querySelectorAll(".attr-plus").forEach((btn) => {
      btn.addEventListener("click", () => {
        const attr = btn.dataset.attr;
        if (G.state.points <= 0) return;
        if (G.state.attrs[attr] >= 5) return;
        G.state.attrs[attr] += 1;
        G.state.points -= 1;
        saveGame();
        UI.panelBody.innerHTML = buildCharPanel();
        bindPanelActions("char");
        updateHUD();
        toast(`<strong>${ATTR_DEFS[attr].name}提升</strong> 现在是 ${G.state.attrs[attr]}`);
      });
    });
  }
  const restart = $("restartBtn");
  if (restart) {
    restart.addEventListener("click", () => {
      closePanel();
      if (typeof resetGame === "function") resetGame();
    });
  }
}

/* ---------------- 环境音 ---------------- */

let ambience = null;

function toggleAmbience() {
  const btn = $("btnSound");
  if (!ambience) {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) throw new Error("unsupported");
      const ctx = new AudioCtx();
      const size = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, size, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      let last = 0;
      for (let i = 0; i < size; i++) {
        const white = Math.random() * 2 - 1;
        last = (last + 0.02 * white) / 1.02;
        data[i] = last * 3.2;
      }
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      src.loop = true;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 560;
      const gain = ctx.createGain();
      gain.gain.value = 0.01;
      src.connect(filter).connect(gain).connect(ctx.destination);
      src.start();
      ambience = { ctx, src, gain, on: true };
      btn.style.color = "var(--sage)";
      toast("<strong>环境音</strong> 咖啡馆的白噪音已开启。");
    } catch (error) {
      toast("当前浏览器不支持环境音。");
    }
  } else {
    ambience.on = !ambience.on;
    ambience.gain.gain.setTargetAtTime(ambience.on ? 0.01 : 0, ambience.ctx.currentTime, 0.2);
    btn.style.color = ambience.on ? "var(--sage)" : "";
    toast(`<strong>环境音</strong> ${ambience.on ? "已开启" : "已关闭"}。`);
  }
}

/* ---------------- 绑定 ---------------- */

let dlgAutoTimer = null;

function bindUI() {
  $("btnJournal").addEventListener("click", () => openPanel("journal"));
  $("btnChar").addEventListener("click", () => openPanel("char"));
  $("btnBag").addEventListener("click", () => openPanel("bag"));
  $("btnSound").addEventListener("click", toggleAmbience);
  $("questGo").addEventListener("click", goToQuest);
  $("panelClose").addEventListener("click", closePanel);
  UI.panel.addEventListener("click", (event) => {
    if (event.target === UI.panel) closePanel();
  });
  bindDialogueKeys();
  bindEndfieldKeys(); // 终末地风格的全局交互
  bindQuestCollapse();
  bindDialogueControls();
}

/* ============ 终末地风格：全局快捷键 ============ */
function bindEndfieldKeys() {
  // Tab：隐藏/显示 HUD（沉浸看场景）
  document.addEventListener("keydown", (e) => {
    if (e.key === "Tab") {
      e.preventDefault();
      document.body.classList.toggle("hidden-hud");
      const on = document.body.classList.contains("hidden-hud");
      toast(`<strong>UI</strong> ${on ? "已隐藏（专注场景）" : "已显示"}`);
    }
  });

  // 顶栏折叠按钮（小圆圈）
  const tog = $("btnHudToggle");
  if (tog) {
    tog.addEventListener("click", () => {
      document.body.classList.toggle("hidden-hud");
    });
  }
}

/* ============ 任务追踪卡折叠 ============ */
function bindQuestCollapse() {
  const q = $("questCard");
  const head = $("questHead");
  const coll = $("questCollapse");
  if (!head || !q) return;
  const toggle = () => {
    q.classList.toggle("is-collapsed");
  };
  head.addEventListener("click", toggle);
  head.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); }
  });
}

/* ============ 对话控制按钮（自动播放 / 沉浸） ============ */
function bindDialogueControls() {
  const autoBtn = $("dlgAuto");
  const hideBtn = $("dlgHide");
  if (!autoBtn || !hideBtn) return;

  autoBtn.addEventListener("click", () => {
    toggleDialogueAuto();
  });
  hideBtn.addEventListener("click", () => {
    toggleDialogueImmersive();
  });

  // H 键：沉浸模式
  document.addEventListener("keydown", (e) => {
    if (e.key.toLowerCase() !== "h") return;
    if (!G.dialogOpen) return;
    e.preventDefault();
    toggleDialogueImmersive();
  });

  // A 键：自动播放
  document.addEventListener("keydown", (e) => {
    if (e.key.toLowerCase() !== "a") return;
    if (!G.dialogOpen) return;
    e.preventDefault();
    toggleDialogueAuto();
  });
}

function toggleDialogueImmersive() {
  if (!UI.dialogue) return;
  UI.dialogue.classList.toggle("is-immersive");
  const on = UI.dialogue.classList.contains("is-immersive");
  const btn = $("dlgHide");
  if (btn) btn.classList.toggle("is-on", on);
  toast(`<strong>沉浸模式</strong> ${on ? "已开启（按 H 恢复）" : "已关闭"}`);
}

function toggleDialogueAuto() {
  if (!UI.dialogue) return;
  // 只有真的多个选项（分支选择）才阻止自动，单个"继续"不算
  const opts = UI.dlgOptions.querySelectorAll(".option-btn");
  const isRealChoice = opts.length > 1;
  if (isRealChoice) {
    toast("有多个选项时无法自动播放，请先选择。");
    return;
  }
  const on = !UI.dialogue.classList.contains("is-auto");
  UI.dialogue.classList.toggle("is-auto", on);
  const btn = $("dlgAuto");
  if (btn) {
    btn.classList.toggle("is-on", on);
    btn.textContent = on ? "⏸" : "▶";
  }
  if (on) {
    startAutoAdvance();
    toast("<strong>自动播放</strong> 已开启（按 A 或点按钮停止）");
  } else {
    stopAutoAdvance();
  }
}

function startAutoAdvance() {
  stopAutoAdvance();
  dlgAutoTimer = setTimeout(() => {
    if (!G.dialogOpen) { stopAutoAdvance(); return; }
    const opts = UI.dlgOptions.querySelectorAll(".option-btn");
    const isRealChoice = opts.length > 1;
    if (isRealChoice) {
      toggleDialogueAuto(); // 遇到选项自动停
      return;
    }
    // 点击唯一的按钮（通常是"继续"）
    const btn = opts[0];
    if (btn) btn.click();
  }, 2800);
}

function stopAutoAdvance() {
  if (dlgAutoTimer) {
    clearTimeout(dlgAutoTimer);
    dlgAutoTimer = null;
  }
}

/* 覆盖原 closeDialogue：停自动播放 + 恢复沉浸状态 */
function closeDialogue() {
  stopAutoAdvance();
  UI.dialogue.classList.remove("is-auto", "is-immersive");
  const autoBtn = $("dlgAuto");
  const hideBtn = $("dlgHide");
  if (autoBtn) { autoBtn.classList.remove("is-on"); autoBtn.textContent = "▶"; }
  if (hideBtn) hideBtn.classList.remove("is-on");
  UI.dialogue.hidden = true;
  G.dialogOpen = false;
  const cb = dialogueOnClose;
  dialogueOnClose = null;
  if (cb) cb();
}
