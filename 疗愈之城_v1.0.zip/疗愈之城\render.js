/* 场景渲染：等距地板、墙体、建筑、家具。 */

function P(x, y, z = 0) {
  return [(x - y) * (TW / 2), (x + y) * (TH / 2) - z * ZH];
}

function initCanvas() {
  G.canvas = document.getElementById("game");
  G.ctx = G.canvas.getContext("2d");
  resizeCanvas();
  window.addEventListener("resize", resizeCanvas);
  if (!G.map) {
    G.state.pos = { x: MAPS.cafe.spawn.x, y: MAPS.cafe.spawn.y };
    loadMap("cafe");
  }
}

function resizeCanvas() {
  if (!G.canvas) return;
  G.dpr = Math.min(window.devicePixelRatio || 1, 2);
  G.vw = window.innerWidth;
  G.vh = window.innerHeight;
  G.canvas.width = Math.floor(G.vw * G.dpr);
  G.canvas.height = Math.floor(G.vh * G.dpr);
  G.canvas.style.width = G.vw + "px";
  G.canvas.style.height = G.vh + "px";
  if (G.map) snapCamera();
  renderStatic();
}

function rrect(ctx, x, y, w, h, r) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function polyPath(ctx, pts) {
  ctx.beginPath();
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
  ctx.closePath();
}

function fillPoly(ctx, pts, fill, stroke, lw) {
  polyPath(ctx, pts);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = lw || 1;
    ctx.stroke();
  }
}

function floorTypeAt(x, y) {
  const m = G.map;
  if (!m) return "wood";
  for (const z of m.floorZones || []) {
    if (z.type === "rug") continue;
    if (x >= z.x && x < z.x + z.w && y >= z.y && y < z.y + z.d) return z.type;
  }
  return m.floor;
}

function drawFloors(ctx) {
  const m = G.map;
  for (let y = 0; y < m.h; y++) {
    for (let x = 0; x < m.w; x++) {
      const type = floorTypeAt(x, y);
      const alt = (x + y) % 2 === 0;
      let fill = "#b2885a";
      let stroke = "rgba(60,38,22,.18)";
      if (type === "wood") { fill = alt ? "#b2885a" : "#a67d4e"; stroke = "rgba(60,38,22,.18)"; }
      else if (type === "stone") {
        fill = alt ? "#a9a196" : "#a29a8e";
        stroke = "rgba(52,46,40,.2)";
      } else if (type === "road") {
        fill = alt ? "#4d4d56" : "#47474f";
        stroke = "rgba(20,20,24,.25)";
      }
      const pts = [P(x, y), P(x + 1, y), P(x + 1, y + 1), P(x, y + 1)];
      fillPoly(ctx, pts, fill, stroke, 0.8);
    }
  }
}

function drawFloorDecals(ctx) {
  const m = G.map;
  (m.floorZones || []).forEach((z) => {
    if (z.type === "rug") {
      const pts = [P(z.x, z.y, 0.015), P(z.x + z.w, z.y, 0.015), P(z.x + z.w, z.y + z.d, 0.015), P(z.x, z.y + z.d, 0.015)];
      fillPoly(ctx, pts, "#77876f", "rgba(224,215,196,.22)", 1.5);
      const inner = [
        P(z.x + 0.25, z.y + 0.25, 0.02),
        P(z.x + z.w - 0.25, z.y + 0.25, 0.02),
        P(z.x + z.w - 0.25, z.y + z.d - 0.25, 0.02),
        P(z.x + 0.25, z.y + z.d - 0.25, 0.02),
      ];
      fillPoly(ctx, inner, "rgba(160,175,150,.16)", "rgba(235,228,208,.16)", 1);
    }
  });

  // 道路中线
  if (m.id === "street") {
    for (let x = 2; x < m.w - 2; x += 2.2) {
      const pts = [
        P(x, 7.42, 0.012),
        P(x + 1.1, 7.42, 0.012),
        P(x + 1.1, 7.56, 0.012),
        P(x, 7.56, 0.012),
      ];
      fillPoly(ctx, pts, "rgba(240,222,184,.22)");
    }
  }
}

/* ---------------- 通用体块 ---------------- */

function boxFaces(ctx, x, y, w, d, h, z, colors, stroke) {
  const z0 = z || 0;
  const A = P(x, y, z0);
  const B = P(x + w, y, z0);
  const C = P(x + w, y + d, z0);
  const D = P(x, y + d, z0);
  const Ah = P(x, y, z0 + h);
  const Bh = P(x + w, y, z0 + h);
  const Ch = P(x + w, y + d, z0 + h);
  const Dh = P(x, y + d, z0 + h);
  fillPoly(ctx, [D, C, Ch, Dh], colors.front, stroke || "rgba(20,14,10,.18)", 1);
  fillPoly(ctx, [B, C, Ch, Bh], colors.side, stroke || "rgba(20,14,10,.18)", 1);
  fillPoly(ctx, [Ah, Bh, Ch, Dh], colors.top, stroke || "rgba(20,14,10,.16)", 1);
  return { A, B, C, D, Ah, Bh, Ch, Dh };
}

function faceRect(ctx, x, y, x1, x2, z1, z2, fill, stroke) {
  const pts = [P(x1, y, z1), P(x2, y, z1), P(x2, y, z2), P(x1, y, z2)];
  fillPoly(ctx, pts, fill, stroke || "rgba(20,14,10,.2)", 1);
}

/* ---------------- 墙体 ---------------- */

function drawWalls(ctx) {
  const m = G.map;
  (m.walls || []).forEach((w) => {
    const colors = { top: "#b5a894", front: "#e2d7c4", side: "#c4b8a4" };
    boxFaces(ctx, w.x, w.y, w.w, w.d, w.h, 0, colors, "rgba(30,18,10,.25)");
  });

  // 墙面简洁内墙线
  if (m.id === "cafe") {
    ctx.strokeStyle = "rgba(80,60,40,.2)";
    ctx.lineWidth = 1;
    // 西墙内侧
    const a = P(1, 1, 1.2);
    const b = P(1, m.h, 1.2);
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
    // 南墙内侧（如果存在）
    if (m.walls.some((w) => w.y + w.d >= m.h)) {
      const c = P(1, m.h - 0.02, 1.2);
      const d = P(m.w - 2, m.h - 0.02, 1.2);
      ctx.beginPath();
      ctx.moveTo(c[0], c[1]);
      ctx.lineTo(d[0], d[1]);
      ctx.stroke();
    }
  }
}

function drawBuildings(ctx) {
  const m = G.map;
  const night = G.state.phase === "night";
  const palette = [
    { front: "#b6886a", side: "#946b52", top: "#c99a79" },
    { front: "#8f7f8a", side: "#776874", top: "#a795a0" },
    { front: "#9f8464", side: "#866d51", top: "#b89a76" },
    { front: "#7e8b86", side: "#687570", top: "#94a19b" },
    { front: "#a67f72", side: "#8b685d", top: "#bd9483" },
  ];
  (m.buildings || []).forEach((b, idx) => {
    const c = palette[idx % palette.length];
    boxFaces(ctx, b.x, b.y, b.w, b.d, b.h, 0, c, "rgba(20,14,10,.24)");
    const fy = b.y + b.d;
    const cols = Math.max(2, Math.round(b.w / 1.4));
    const rows = Math.max(2, Math.round(b.h / 0.85));
    for (let r = 0; r < rows; r++) {
      for (let i = 0; i < cols; i++) {
        const x1 = b.x + 0.3 + i * (b.w - 0.6) / cols + 0.12;
        const x2 = b.x + 0.3 + (i + 1) * (b.w - 0.6) / cols - 0.12;
        const z1 = 0.42 + r * (b.h - 0.6) / rows + 0.1;
        const z2 = 0.42 + (r + 1) * (b.h - 0.6) / rows - 0.06;
        const lit = night && (i + r) % 3 === 0;
        faceRect(ctx, fy, x1, x2, z1, z2, lit ? "rgba(255,203,132,.42)" : "rgba(38,44,54,.42)", "rgba(24,20,18,.3)");
      }
    }
    if (b.sign) {
      const [sx, sy] = P(b.x + b.w / 2, fy, b.h - 0.35);
      ctx.save();
      ctx.font = '600 12px "PingFang SC","Microsoft YaHei",sans-serif';
      const tw = ctx.measureText(b.sign).width;
      rrect(ctx, sx - tw / 2 - 9, sy - 11, tw + 18, 21, 6);
      ctx.fillStyle = "rgba(28,22,18,.82)";
      ctx.fill();
      ctx.strokeStyle = "rgba(232,165,110,.34)";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = "#e8c79c";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(b.sign, sx, sy + 1);
      ctx.restore();
    }
  });
}

function drawBorderWalls(ctx) {
  const m = G.map;
  const night = G.state.phase === "night";
  (m.borderWalls || []).forEach((b) => {
    if (b.fence) {
      boxFaces(ctx, b.x, b.y, b.w, b.d, b.h, 0, { top: "#6c7166", front: "#565c53", side: "#474d46" }, "rgba(16,14,12,.3)");
      ctx.strokeStyle = "rgba(214,226,208,.22)";
      ctx.lineWidth = 1.2;
      for (let i = 1; i < b.w; i++) {
        const a = P(b.x + i, b.y + b.d, 0);
        const c = P(b.x + i, b.y + b.d, b.h);
        ctx.beginPath();
        ctx.moveTo(a[0], a[1]);
        ctx.lineTo(c[0], c[1]);
        ctx.stroke();
      }
    } else {
      const colors = night
        ? { top: "#5b6159", front: "#4a514c", side: "#3d443f" }
        : { top: "#b9b3a4", front: "#a59e90", side: "#918b7e" };
      boxFaces(ctx, b.x, b.y, b.w, b.d, b.h, 0, colors, "rgba(18,16,14,.3)");
    }
  });
}

/* ---------------- 家具与街景 ---------------- */

function drawProps(ctx) {
  const items = [];
  (G.map.props || []).forEach((p) => {
    const depth = (p.x || 0) + (p.w || 1) / 2 + (p.y || 0) + (p.d || 1) / 2 + (p.type === "pendant" ? 0.4 : 0);
    items.push({ kind: "prop", p, depth });
  });
  items.sort((a, b) => a.depth - b.depth);
  items.forEach((it) => drawProp(ctx, it.p));
}

function drawProp(ctx, p) {
  switch (p.type) {
    case "counter": return drawCounter(ctx, p);
    case "backBar": return drawBackBar(ctx, p);
    case "cupRack": return drawCupRack(ctx, p);
    case "machine": return drawMachine(ctx, p);
    case "register": return drawRegister(ctx, p);
    case "cupstack": return drawCups(ctx, p);
    case "terminal": return drawTerminal(ctx, p);
    case "booth": return drawBooth(ctx, p);
    case "roundTable": return drawRoundTable(ctx, p);
    case "table":
    case "longtable": return drawTable(ctx, p);
    case "chair": return drawChair(ctx, p);
    case "stool": return drawStool(ctx, p);
    case "shelf": return drawShelf(ctx, p);
    case "plant": return drawPlant(ctx, p);
    case "pendant": return drawPendant(ctx, p);
    case "wallArt": return drawWallArt(ctx, p);
    case "catBed": return drawCatBed(ctx, p);
    case "floorBowl": return drawFloorBowl(ctx, p);
    case "cat": return drawCat(ctx, p);
    case "paper": return drawPaper(ctx, p);
    case "mat": return drawMat(ctx, p);
    case "door": return drawCafeDoor(ctx, p);
    case "streetlamp": return drawStreetlamp(ctx, p);
    case "tree": return drawTree(ctx, p);
    case "vending": return drawVending(ctx, p);
    case "shelter": return drawShelter(ctx, p);
    case "bench": return drawBench(ctx, p);
    case "car": return drawCar(ctx, p);
    case "signboard": return drawSignboard(ctx, p);
    case "puddle": return drawPuddle(ctx, p);
    case "cafeFacade": return drawFacadeDoor(ctx, p);
    default: return;
  }
}

function drawCounter(ctx, p) {
  // 深木质吧台（咖啡馆3复古风）
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, (p.w + p.d) * 15, (p.w + p.d) * 3.4, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(40,22,14,.2)";
  ctx.fill();
  // 吧台主体：深木色
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, 0, { top: "#d4a574", front: "#6e4830", side: "#4d3120" }, "rgba(20,12,6,.3)");
  // 台面木边
  boxFaces(ctx, p.x - 0.04, p.y - 0.04, p.w + 0.08, p.d + 0.08, 0.06, p.h, { top: "#c49466", front: "#8a5c3a", side: "#643f28" }, "rgba(20,12,6,.25)");
  // 前脸竖向木纹
  const fy = p.y + p.d;
  for (let i = 0; i < Math.floor(p.w); i++) {
    const x = p.x + 0.5 + i;
    ctx.strokeStyle = "rgba(30,18,10,.3)";
    ctx.lineWidth = 1;
    const a = P(x, fy, 0.08);
    const b = P(x, fy, p.h - 0.05);
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
  }
}

function drawBackBar(ctx, p) {
  // 吧台后方不锈钢设备柜（咖啡馆3复古风）
  const fy = p.y + p.d;
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, 0, { top: "#8a8e8c", front: "#5c6160", side: "#3e4342" }, "rgba(10,10,12,.35)");
  // 柜门分隔（竖向细缝）
  for (let i = 1; i < Math.floor(p.w / 1.3); i++) {
    const x = p.x + i * 1.3;
    ctx.strokeStyle = "rgba(15,15,18,.4)";
    ctx.lineWidth = 1;
    const a = P(x, fy, 0.05);
    const b = P(x, fy, p.h - 0.03);
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
  }
  // 台面反光
  const topY = P(p.x, p.y, p.h)[1];
  ctx.fillStyle = "rgba(255,255,255,.08)";
  const [hxa, hya] = P(p.x + 0.2, p.y + 0.2, p.h + 0.01);
  const [hxb, hyb] = P(p.x + p.w - 0.3, p.y + 0.3, p.h + 0.01);
  ctx.beginPath();
  ctx.moveTo(hxa, hya);
  ctx.lineTo(hxb, hyb);
  ctx.lineWidth = 1.2;
  ctx.strokeStyle = "rgba(255,255,255,.12)";
  ctx.stroke();
}

function drawCupRack(ctx, p) {
  // 墙上两层杯架
  const fy = p.y + p.d;
  const zTop = p.z || 1.8;
  const shelfH = 0.12;
  // 上层搁板
  faceRect(ctx, fy, p.x, p.x + p.w, zTop - shelfH, zTop, "#c4b49a", "rgba(80,68,52,.18)");
  // 下层搁板
  faceRect(ctx, fy, p.x, p.x + p.w, zTop - 0.55 - shelfH, zTop - 0.55, "#c4b49a", "rgba(80,68,52,.18)");
  // 杯子（白色/米色小杯，倒扣/正放）
  const cupsPerShelf = Math.max(3, Math.floor(p.w / 0.35));
  for (let i = 0; i < cupsPerShelf; i++) {
    const cx = p.x + 0.12 + i * (p.w - 0.24) / cupsPerShelf + 0.1;
    // 上层：倒扣白色杯
    const [ux, uy] = P(cx, fy, zTop + 0.08);
    ctx.beginPath();
    ctx.ellipse(ux, uy, 3.5, 1.6, 0, 0, Math.PI * 2);
    ctx.fillStyle = i % 3 === 0 ? "#f3eadb" : "#efe4d0";
    ctx.fill();
    // 下层：正放米色杯
    const [lx, ly] = P(cx + 0.18, fy, zTop - 0.55 + 0.18);
    ctx.beginPath();
    ctx.ellipse(lx, ly, 3, 1.4, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#e5d7bf";
    ctx.fill();
  }
}

function drawMachine(ctx, p) {
  // 咖啡机（设定2风格：金属银 + 黑色）
  const z = p.z || 0;
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, z, { top: "#8b8f8c", front: "#5e6360", side: "#444946" }, "rgba(20,20,22,.28)");
  // 顶部黑色
  faceRect(ctx, p.y + p.d, p.x + 0.08, p.x + p.w - 0.08, z + p.h - 0.08, z + p.h, "#1a1b1c");
  // 操作面板指示灯
  const [lx, ly] = P(p.x + 0.5, p.y + p.d, z + p.h - 0.14);
  ctx.beginPath();
  ctx.arc(lx, ly, 1.5, 0, Math.PI * 2);
  ctx.fillStyle = "#e8a56e";
  ctx.fill();
  // 出水口
  const [gx, gy] = P(p.x + p.w / 2, p.y + p.d, z + 0.1);
  ctx.strokeStyle = "#3a3d3b";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(gx, gy);
  ctx.lineTo(gx, gy + 10);
  ctx.stroke();
}

function drawRegister(ctx, p) {
  const z = p.z || 0;
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, z, { top: "#d9cdbb", front: "#91806b", side: "#786653" }, "rgba(30,24,18,.2)");
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d, z + p.h * 0.8);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 7, 3, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#e8a56e";
  ctx.fill();
}

function drawCups(ctx, p) {
  const z = p.z || 0;
  for (let i = 0; i < 3; i++) {
    const [sx, sy] = P(p.x + 0.2 + i * 0.18, p.y + p.d / 2, z + 0.08 + i * 0.06);
    ctx.beginPath();
    ctx.ellipse(sx, sy, 6, 2.8, 0, 0, Math.PI * 2);
    ctx.fillStyle = "#f3eadb";
    ctx.fill();
  }
}

function drawTerminal(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 24, 8, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(30,22,16,.18)";
  ctx.fill();
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, 0, { top: "#3c3f3e", front: "#33352f", side: "#252722" }, "rgba(8,8,8,.35)");
  faceRect(ctx, p.y + p.d, p.x + 0.18, p.x + p.w - 0.18, 0.55, 1.02, "#1d2a2d", "rgba(232,165,110,.3)");
  const [gx, gy] = P(p.x + p.w / 2, p.y + p.d, 0.85);
  ctx.beginPath();
  ctx.arc(gx, gy, 9, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(232,165,110,.9)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,236,210,.5)";
  ctx.lineWidth = 1;
  ctx.stroke();
}

function drawTable(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, (p.w + p.d) * 12, (p.w + p.d) * 2.6, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(40,26,18,.14)";
  ctx.fill();
  const top = { top: "#d5ab7f", front: "#a97c55", side: "#87603f" };
  boxFaces(ctx, p.x, p.y, p.w, p.d, 0.1, p.h - 0.1, top, "rgba(40,26,18,.2)");
  // 桌腿
  const legs = [
    [p.x + 0.25, p.y + 0.25],
    [p.x + p.w - 0.25, p.y + 0.25],
    [p.x + 0.25, p.y + p.d - 0.25],
    [p.x + p.w - 0.25, p.y + p.d - 0.25],
  ];
  legs.forEach(([lx, ly]) => {
    const a = P(lx, ly, p.h - 0.1);
    const b = P(lx, ly, 0);
    ctx.strokeStyle = "#6f4c34";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
  });
  // 桌上杯子
  const [cx, cy] = P(p.x + p.w * 0.62, p.y + p.d * 0.35, p.h + 0.03);
  ctx.beginPath();
  ctx.ellipse(cx, cy, 5.5, 2.2, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#f2e7d8";
  ctx.fill();
}

function drawChair(ctx, p) {
  const dir = p.dir || "down";
  const seatZ = 0.44;
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 16, 5, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(40,26,18,.12)";
  ctx.fill();
  boxFaces(ctx, p.x, p.y, p.w, p.d, 0.07, seatZ, { top: "#cfa67f", front: "#9a6f50", side: "#7a5741" }, "rgba(50,32,22,.2)");
  const back = { top: "#a07a58", front: "#8a6547", side: "#6e4f38" };
  let bx = p.x;
  let by = p.y;
  let bw = p.w;
  let bd = 0.08;
  if (dir === "right") { bx = p.x; by = p.y; bw = 0.08; bd = p.d; }
  else if (dir === "left") { bx = p.x + p.w - 0.08; by = p.y; bw = 0.08; bd = p.d; }
  else if (dir === "down") { bx = p.x; by = p.y; bw = p.w; bd = 0.08; }
  else { bx = p.x; by = p.y + p.d - 0.08; bw = p.w; bd = 0.08; }
  boxFaces(ctx, bx, by, bw, bd, 0.5, seatZ, back, "rgba(50,32,22,.2)");
  // 椅腿
  const legs = [
    [p.x + 0.06, p.y + 0.06],
    [p.x + p.w - 0.06, p.y + 0.06],
    [p.x + 0.06, p.y + p.d - 0.06],
    [p.x + p.w - 0.06, p.y + p.d - 0.06],
  ];
  ctx.strokeStyle = "rgba(60,42,30,.7)";
  ctx.lineWidth = 1.5;
  legs.forEach(([lx, ly]) => {
    const a = P(lx, ly, seatZ);
    const b = P(lx, ly, 0);
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
  });
}

function drawStool(ctx, p) {
  // 绿色软垫圆凳（咖啡馆3复古风）
  const seatZ = 0.52;
  const [bx, by] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(bx, by, 16, 5, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(30,18,12,.18)";
  ctx.fill();
  // 木色座盘
  boxFaces(ctx, p.x + 0.06, p.y + 0.06, p.w - 0.12, p.d - 0.12, 0.06, seatZ, { top: "#8a5c3a", front: "#6e4830", side: "#4d3120" }, "rgba(20,12,6,.25)");
  // 绿色软垫（椭圆形覆盖在座盘上）
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2, seatZ + 0.06);
  ctx.beginPath();
  ctx.ellipse(sx, sy - 1, 13, 4.5, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#5a7058";
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(sx, sy - 2, 11, 3.8, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#6b8269";
  ctx.fill();
  // 深棕木腿
  const legColor = "#4d3120";
  const legs = [
    [p.x + 0.1, p.y + 0.1], [p.x + p.w - 0.1, p.y + 0.1],
    [p.x + 0.1, p.y + p.d - 0.1], [p.x + p.w - 0.1, p.y + p.d - 0.1],
  ];
  ctx.strokeStyle = legColor;
  ctx.lineWidth = 2;
  legs.forEach(([lx, ly]) => {
    const a = P(lx, ly, seatZ);
    const b = P(lx, ly, 0);
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
  });
}

function drawCatBed(ctx, p) {
  // 圆形猫窝（咖啡馆3角落）
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, (p.w + p.d) * 14, (p.w + p.d) * 4.5, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(30,18,12,.22)";
  ctx.fill();
  // 外层（米色）
  ctx.beginPath();
  ctx.ellipse(sx, sy - 1, (p.w + p.d) * 12, (p.w + p.d) * 4, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#e8dcc5";
  ctx.fill();
  ctx.strokeStyle = "rgba(120,100,80,.22)";
  ctx.lineWidth = 1;
  ctx.stroke();
  // 内层
  ctx.beginPath();
  ctx.ellipse(sx, sy + 2, (p.w + p.d) * 9, (p.w + p.d) * 3, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#cdbf9f";
  ctx.fill();
}

function drawFloorBowl(ctx, p) {
  // 猫食盆
  const [bx, by] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(bx, by, 13, 4.5, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(20,12,6,.18)";
  ctx.fill();
  const z = p.z || 0;
  boxFaces(ctx, p.x, p.y, p.w, p.d, 0.18, z, { top: "#c4b28a", front: "#8a7856", side: "#6d5c3e" }, "rgba(20,12,6,.3)");
  const [ix, iy] = P(p.x + p.w / 2, p.y + p.d / 2, z + 0.18);
  ctx.beginPath();
  ctx.ellipse(ix, iy, 9, 3, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#8a7856";
  ctx.fill();
}

function drawShelf(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 22, 7, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(35,24,18,.16)";
  ctx.fill();
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, 0, { top: "#6f4d3a", front: "#6b4835", side: "#513729" }, "rgba(28,18,12,.3)");
  const fy = p.y + p.d;
  const bookColors = ["#a1755a", "#7d8a6f", "#b08d5b", "#5f7a7c", "#9a6b63", "#c9a06b"];
  for (let row = 0; row < 3; row++) {
    const z1 = 0.28 + row * 0.48;
    const z2 = z1 + 0.36;
    faceRect(ctx, fy, p.x + 0.08, p.x + p.w - 0.08, z1, z2, "rgba(30,22,18,.5)");
    for (let i = 0; i < 7; i++) {
      const x1 = p.x + 0.12 + i * (p.w - 0.24) / 7;
      const x2 = x1 + (p.w - 0.24) / 7 - 0.02;
      const c = bookColors[(row * 7 + i) % bookColors.length];
      const zh = 0.2 + ((i + row) % 3) * 0.05;
      faceRect(ctx, fy, x1, x2, z1, z1 + zh, c, "rgba(20,14,10,.2)");
    }
  }
}

function drawPlant(ctx, p) {
  const size = p.size || 1;
  const [bx, by] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(bx, by, 20 * size, 6 * size, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(30,22,16,.14)";
  ctx.fill();
  boxFaces(ctx, p.x, p.y, p.w, p.d, 0.48 * size, 0, { top: "#cf9a72", front: "#b87950", side: "#955f40" }, "rgba(40,26,18,.2)");
  const base = P(p.x + p.w / 2, p.y + p.d / 2, 0.45 * size);
  const leaves = [
    [-18, -30, -42, -66, -6, -56],
    [0, -36, -16, -86, 14, -70],
    [18, -30, 40, -68, 8, -54],
    [-8, -50, -26, -96, 4, -76],
    [12, -52, 30, -98, -2, -78],
  ];
  leaves.forEach(([x1, y1, cx, cy, x2, y2], i) => {
    ctx.beginPath();
    ctx.moveTo(base[0] + x1 * size, base[1] + y1 * size);
    ctx.quadraticCurveTo(base[0] + cx * size, base[1] + cy * size, base[0] + x2 * size, base[1] + y2 * size);
    ctx.strokeStyle = i % 2 ? "#6f866c" : "#587055";
    ctx.lineWidth = 2.6 * size;
    ctx.lineCap = "round";
    ctx.stroke();
  });
}

function drawPendant(ctx, p) {
  // 锥形木色吊灯（设定2风格）
  const z = p.z || 2.8;
  const [sx, sy] = P(p.x, p.y, z);
  const topY = sy - 68;
  ctx.strokeStyle = "rgba(70,58,44,.65)";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(sx, topY);
  ctx.lineTo(sx, sy - 24);
  ctx.stroke();
  // 锥形灯罩（木色外 + 暖色内光）
  const hw = 28;
  const ht = 22;
  ctx.beginPath();
  ctx.moveTo(sx - 4, sy - 26);
  ctx.lineTo(sx + 4, sy - 26);
  ctx.lineTo(sx + hw, sy);
  ctx.lineTo(sx - hw, sy);
  ctx.closePath();
  ctx.fillStyle = "#d2bc9e";
  ctx.fill();
  ctx.strokeStyle = "rgba(120,95,68,.45)";
  ctx.lineWidth = 1;
  ctx.stroke();
  // 灯罩内层暖光
  ctx.beginPath();
  ctx.moveTo(sx - 3, sy - 24);
  ctx.lineTo(sx + 3, sy - 24);
  ctx.lineTo(sx + hw - 4, sy - 1);
  ctx.lineTo(sx - hw + 4, sy - 1);
  ctx.closePath();
  ctx.fillStyle = "rgba(255,205,140,.35)";
  ctx.fill();
  // 灯泡
  ctx.beginPath();
  ctx.arc(sx, sy - 1, 4, 0, Math.PI * 2);
  ctx.fillStyle = "#ffe8b8";
  ctx.fill();
}

function drawCat(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 22, 7, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(40,30,24,.14)";
  ctx.fill();
  const bob = Math.sin(G.time * 2.2) * 1.5;
  ctx.beginPath();
  ctx.ellipse(sx, sy - 9 + bob, 18, 8, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#f0e6d6";
  ctx.fill();
  ctx.beginPath();
  ctx.arc(sx + 12, sy - 15 + bob, 8, 0, Math.PI * 2);
  ctx.fillStyle = "#f5ecdd";
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(sx + 7, sy - 20 + bob);
  ctx.lineTo(sx + 10, sy - 27 + bob);
  ctx.lineTo(sx + 13, sy - 20 + bob);
  ctx.moveTo(sx + 13, sy - 20 + bob);
  ctx.lineTo(sx + 17, sy - 27 + bob);
  ctx.lineTo(sx + 19, sy - 19 + bob);
  ctx.fillStyle = "#f5ecdd";
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(sx - 17, sy - 6 + bob);
  ctx.quadraticCurveTo(sx - 30, sy - 14 + bob, sx - 26, sy - 22 + bob);
  ctx.strokeStyle = "#e6d8c5";
  ctx.lineWidth = 4;
  ctx.stroke();
  ctx.fillStyle = "rgba(80,60,48,.6)";
  ctx.beginPath();
  ctx.arc(sx + 9, sy - 16 + bob, 1.2, 0, Math.PI * 2);
  ctx.arc(sx + 15, sy - 16 + bob, 1.2, 0, Math.PI * 2);
  ctx.fill();
}

function drawPaper(ctx, p) {
  const pts = [P(p.x, p.y, 0.02), P(p.x + p.w, p.y, 0.02), P(p.x + p.w, p.y + p.d, 0.02), P(p.x, p.y + p.d, 0.02)];
  fillPoly(ctx, pts, "#efe7d8", "rgba(120,95,70,.3)", 0.8);
  const mid1 = P(p.x + 0.12, p.y + p.d * 0.4, 0.025);
  const mid2 = P(p.x + p.w - 0.1, p.y + p.d * 0.4, 0.025);
  ctx.strokeStyle = "rgba(120,100,80,.35)";
  ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(mid1[0], mid1[1]);
  ctx.lineTo(mid2[0], mid2[1]);
  ctx.stroke();
}

function drawMat(ctx, p) {
  // 米色门垫（设定2风格）
  const pts = [P(p.x, p.y, 0.012), P(p.x + p.w, p.y, 0.012), P(p.x + p.w, p.y + p.d, 0.012), P(p.x, p.y + p.d, 0.012)];
  fillPoly(ctx, pts, "#d4c9b3", "rgba(120,100,80,.18)", 1);
  // 内部边缘稍深
  const inner = [P(p.x + 0.08, p.y + 0.08, 0.014), P(p.x + p.w - 0.08, p.y + 0.08, 0.014), P(p.x + p.w - 0.08, p.y + p.d - 0.08, 0.014), P(p.x + 0.08, p.y + p.d - 0.08, 0.014)];
  fillPoly(ctx, inner, "rgba(200,185,160,.18)");
}

function drawWallArt(ctx, p) {
  // 植物主题装饰画（西墙上）
  const fy = p.y + p.d;
  const z1 = p.z || 0.5;
  const h = p.h || 0.6;
  // 画框（窄木边）
  faceRect(ctx, fy, p.x, p.x + p.w, z1, z1 + h, "#f2ede3", "rgba(100,90,78,.3)");
  // 画框边框
  const bw = 0.04;
  faceRect(ctx, fy, p.x, p.x + bw, z1, z1 + h, "#b4a58e");
  faceRect(ctx, fy, p.x + p.w - bw, p.x + p.w, z1, z1 + h, "#b4a58e");
  faceRect(ctx, fy, p.x, p.x + p.w, z1, z1 + bw, "#b4a58e");
  faceRect(ctx, fy, p.x, p.x + p.w, z1 + h - bw, z1 + h, "#b4a58e");
  // 画芯：植物剪影（深绿椭圆）
  const cx = p.x + p.w / 2;
  const cz = z1 + h * 0.5;
  const [px, py] = P(cx, fy, cz);
  ctx.beginPath();
  ctx.ellipse(px, py, (p.w * TW / 2) * 0.35, h * ZH * 0.3, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#5e7a5a";
  ctx.fill();
  // 植物茎叶（细绿线）
  ctx.strokeStyle = "#6a8a66";
  ctx.lineWidth = 1.2;
  const [bx, by] = P(cx, fy, cz - h * 0.22);
  ctx.beginPath();
  ctx.moveTo(bx, by);
  ctx.lineTo(px + 4, py - 12);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(bx, by);
  ctx.lineTo(px - 4, py - 10);
  ctx.stroke();
}

function drawBooth(ctx, p) {
  // L形米白布艺卡座（设定2风格）
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, (p.w + p.d) * 13, (p.w + p.d) * 2.8, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(40,35,28,.08)";
  ctx.fill();
  const seatZ = 0.48;
  // 坐垫（米白色）
  boxFaces(ctx, p.x, p.y, p.w, p.d, 0.14, seatZ, { top: "#f2ede3", front: "#d8d1c3", side: "#c9c1b2" }, "rgba(100,90,78,.12)");
  // 靠垫（内侧短边和长边）
  const backH = 0.48;
  const backZ = seatZ + 0.14;
  // 长边靠背
  boxFaces(ctx, p.x, p.y, p.w, 0.22, backH, backZ, { top: "#efe7d8", front: "#cdc4b4", side: "#bdb4a4" }, "rgba(100,90,78,.12)");
  // 短边靠背（L形内侧）
  boxFaces(ctx, p.x + p.d - 0.22, p.y, p.d, p.w, backH, backZ, { top: "#efe7d8", front: "#cdc4b4", side: "#bdb4a4" }, "rgba(100,90,78,.12)");
  // 靠垫点缀（4个小方靠垫）
  const cushions = [
    [p.x + 0.55, p.y + 0.5],
    [p.x + p.w - 0.7, p.y + 0.5],
    [p.x + p.w * 0.5, p.y + p.d * 0.5],
  ];
  cushions.forEach(([cx, cy], i) => {
    boxFaces(ctx, cx - 0.18, cy - 0.18, 0.36, 0.36, 0.06, backZ + backH, { top: i % 2 ? "#e8dcc5" : "#ece1ce", front: "#cbbca4", side: "#bdae96" }, "rgba(100,90,78,.1)");
  });
}

function drawRoundTable(ctx, p) {
  // 圆形木茶几（设定2风格）
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, (p.w + p.d) * 12, (p.w + p.d) * 2.4, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(40,35,28,.08)";
  ctx.fill();
  const topZ = p.h || 0.55;
  // 圆形桌面
  const [tx, ty] = P(p.x + p.w / 2, p.y + p.d / 2, topZ);
  ctx.beginPath();
  ctx.ellipse(tx, ty, 18, 6, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#d6c8a8";
  ctx.fill();
  ctx.strokeStyle = "rgba(100,90,70,.25)";
  ctx.lineWidth = 0.8;
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(tx, ty - 1.2, 15, 4.8, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#e8dcc0";
  ctx.fill();
  // 桌腿（单柱 + 底座）
  const [mx, my] = P(p.x + p.w / 2, p.y + p.d / 2, topZ / 2);
  const [bx, by] = P(p.x + p.w / 2, p.y + p.d / 2, 0.02);
  ctx.strokeStyle = "#a89976";
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.moveTo(tx, ty);
  ctx.lineTo(mx, my);
  ctx.stroke();
  // 底座
  ctx.beginPath();
  ctx.ellipse(bx, by, 12, 4, 0, 0, Math.PI * 2);
  ctx.fillStyle = "#a89976";
  ctx.fill();
}

function drawCafeDoor(ctx, p) {
  const fy = p.y + p.d;
  const frame = "#6d4f3b";
  faceRect(ctx, fy, p.x, p.x + p.w, 0, p.h, "rgba(42,50,52,.35)", "rgba(30,20,14,.4)");
  faceRect(ctx, fy, p.x + 0.06, p.x + p.w / 2 - 0.06, 0.08, p.h - 0.1, "rgba(160,188,188,.2)", "rgba(240,232,210,.22)");
  faceRect(ctx, fy, p.x + p.w / 2 + 0.06, p.x + p.w - 0.06, 0.08, p.h - 0.1, "rgba(160,188,188,.2)", "rgba(240,232,210,.22)");
  faceRect(ctx, fy, p.x, p.x + 0.06, 0, p.h, frame);
  faceRect(ctx, fy, p.x + p.w - 0.06, p.x + p.w, 0, p.h, frame);
  faceRect(ctx, fy, p.x, p.x + p.w, p.h - 0.08, p.h, frame);
  faceRect(ctx, fy, p.x + p.w / 2 - 0.03, p.x + p.w / 2 + 0.03, 0, p.h, frame);
  // 门把手
  const [hx, hy] = P(p.x + p.w / 2 - 0.12, fy, 0.62);
  ctx.beginPath();
  ctx.arc(hx, hy, 2.4, 0, Math.PI * 2);
  ctx.fillStyle = "#d9b483";
  ctx.fill();
}

function drawStreetlamp(ctx, p) {
  const [bx, by] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(bx, by, 12, 4, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(20,18,16,.18)";
  ctx.fill();
  const top = P(p.x + p.w / 2, p.y + p.d / 2, p.h);
  ctx.strokeStyle = "#363b38";
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(bx, by);
  ctx.lineTo(top[0], top[1]);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(top[0], top[1]);
  ctx.lineTo(top[0] + 16, top[1] - 5);
  ctx.stroke();
  const [lx, ly] = [top[0] + 16, top[1] - 5];
  ctx.beginPath();
  ctx.moveTo(lx - 7, ly + 2);
  ctx.lineTo(lx + 7, ly + 2);
  ctx.lineTo(lx + 4, ly + 9);
  ctx.lineTo(lx - 4, ly + 9);
  ctx.closePath();
  ctx.fillStyle = "#f3d49b";
  ctx.fill();
}

function drawTree(ctx, p) {
  const size = p.size || 1;
  const [bx, by] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(bx, by, 24 * size, 8 * size, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(20,18,16,.16)";
  ctx.fill();
  ctx.strokeStyle = "#57493a";
  ctx.lineWidth = 4 * size;
  ctx.beginPath();
  ctx.moveTo(bx, by);
  ctx.lineTo(bx, by - 52 * size);
  ctx.stroke();
  const blobs = [
    [0, -78, 28],
    [-20, -64, 20],
    [20, -62, 21],
    [-8, -92, 18],
  ];
  blobs.forEach(([ox, oy, r], i) => {
    ctx.beginPath();
    ctx.arc(bx + ox * size, by + oy * size, r * size, 0, Math.PI * 2);
    ctx.fillStyle = i % 2 ? "rgba(102,124,94,.92)" : "rgba(88,110,82,.94)";
    ctx.fill();
  });
}

function drawVending(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 20, 7, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(20,18,16,.16)";
  ctx.fill();
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, 0, { top: "#4b5452", front: "#39424a", side: "#2b3238" }, "rgba(12,12,14,.35)");
  faceRect(ctx, p.y + p.d, p.x + 0.12, p.x + p.w - 0.12, 0.45, p.h - 0.12, "#e8b579", "rgba(255,240,210,.3)");
  const [gx, gy] = P(p.x + p.w / 2, p.y + p.d, p.h * 0.5);
  ctx.beginPath();
  ctx.arc(gx, gy, 12, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(255,225,180,.75)";
  ctx.fill();
  ctx.fillStyle = "rgba(80,50,30,.7)";
  for (let i = 0; i < 3; i++) {
    ctx.fillRect(gx - 8 + i * 6, gy - 4, 3, 8);
  }
  faceRect(ctx, p.y + p.d, p.x + 0.18, p.x + p.w - 0.18, 0.18, 0.36, "rgba(20,20,22,.9)");
}

function drawShelter(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 34, 10, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(20,18,16,.14)";
  ctx.fill();
  // 顶棚
  boxFaces(ctx, p.x + 0.1, p.y, p.w - 0.2, p.d + 0.2, 0.12, 1.25, { top: "#7f8f8a", front: "#63726e", side: "#4e5c58" }, "rgba(20,20,20,.3)");
  // 支柱
  [[p.x + 0.2, p.y + 0.1], [p.x + p.w - 0.2, p.y + 0.1]].forEach(([lx, ly]) => {
    const a = P(lx, ly, 1.25);
    const b = P(lx, ly, 0);
    ctx.strokeStyle = "#3f4642";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
  });
  // 长椅
  boxFaces(ctx, p.x + 0.35, p.y + 0.35, p.w - 0.7, 0.35, 0.1, 0.45, { top: "#b08763", front: "#8b674a", side: "#6d4f39" }, "rgba(30,20,14,.25)");
  // 站牌
  const [px, py] = P(p.x + p.w - 0.3, p.y + p.d, 1.3);
  ctx.beginPath();
  ctx.arc(px, py, 9, 0, Math.PI * 2);
  ctx.fillStyle = "#7fa292";
  ctx.fill();
  ctx.strokeStyle = "rgba(240,245,235,.4)";
  ctx.lineWidth = 1;
  ctx.stroke();
}

function drawBench(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 26, 7, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(20,18,16,.14)";
  ctx.fill();
  boxFaces(ctx, p.x, p.y, p.w, p.d, 0.12, p.h - 0.12, { top: "#b98d63", front: "#916841", side: "#74502f" }, "rgba(30,20,14,.25)");
  boxFaces(ctx, p.x, p.y, p.w, 0.1, 0.42, p.h, { top: "#a67c55", front: "#8a6440", side: "#6f4d30" }, "rgba(30,20,14,.25)");
  [[p.x + 0.2, p.y + p.d - 0.1], [p.x + p.w - 0.2, p.y + p.d - 0.1]].forEach(([lx, ly]) => {
    const a = P(lx, ly, p.h - 0.12);
    const b = P(lx, ly, 0);
    ctx.strokeStyle = "#4d4640";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(a[0], a[1]);
    ctx.lineTo(b[0], b[1]);
    ctx.stroke();
  });
}

function drawCar(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.beginPath();
  ctx.ellipse(sx, sy, 44, 12, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(10,10,14,.22)";
  ctx.fill();
  boxFaces(ctx, p.x, p.y, p.w, p.d, p.h, 0, { top: "#5a6b74", front: "#43525b", side: "#34414a" }, "rgba(10,12,16,.3)");
  boxFaces(ctx, p.x + 0.5, p.y + 0.15, p.w - 1, p.d - 0.3, 0.5, p.h, { top: "#9fb4b8", front: "#6f858c", side: "#576b72" }, "rgba(10,12,16,.3)");
  const [wx1, wy1] = P(p.x + 0.4, p.y + p.d, 0.15);
  const [wx2, wy2] = P(p.x + p.w - 0.4, p.y + p.d, 0.15);
  ctx.beginPath();
  ctx.arc(wx1, wy1, 6, 0, Math.PI * 2);
  ctx.arc(wx2, wy2, 6, 0, Math.PI * 2);
  ctx.fillStyle = "#23262a";
  ctx.fill();
}

function drawSignboard(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2);
  ctx.strokeStyle = "#5c4433";
  ctx.lineWidth = 2;
  const top = P(p.x + p.w / 2, p.y + p.d / 2, p.h);
  ctx.beginPath();
  ctx.moveTo(sx, sy);
  ctx.lineTo(top[0], top[1]);
  ctx.stroke();
  ctx.save();
  ctx.translate(top[0], top[1] - 6);
  ctx.rotate(-0.06);
  rrect(ctx, -16, -9, 32, 18, 4);
  ctx.fillStyle = "#f0e3ce";
  ctx.fill();
  ctx.strokeStyle = "rgba(90,66,48,.5)";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#7a5a40";
  ctx.font = '600 9px "PingFang SC","Microsoft YaHei",sans-serif';
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("OPEN", 0, 1);
  ctx.restore();
}

function drawPuddle(ctx, p) {
  const [sx, sy] = P(p.x + p.w / 2, p.y + p.d / 2, 0.01);
  ctx.beginPath();
  ctx.ellipse(sx, sy, p.w * 17, p.d * 9, 0, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(120,142,150,.14)";
  ctx.fill();
  ctx.strokeStyle = "rgba(180,205,210,.12)";
  ctx.lineWidth = 1;
  ctx.stroke();
}

function drawFacadeDoor(ctx, p) {
  const fy = p.y + p.d;
  faceRect(ctx, fy, p.x, p.x + p.w, 0, p.h, "rgba(34,40,44,.55)", "rgba(24,18,16,.35)");
  faceRect(ctx, fy, p.x + 0.1, p.x + p.w / 2 - 0.05, 0.1, p.h - 0.08, "rgba(226,190,150,.2)", "rgba(245,230,205,.25)");
  faceRect(ctx, fy, p.x + p.w / 2 + 0.05, p.x + p.w - 0.1, 0.1, p.h - 0.08, "rgba(226,190,150,.2)", "rgba(245,230,205,.25)");
  faceRect(ctx, fy, p.x + p.w / 2 - 0.03, p.x + p.w / 2 + 0.03, 0, p.h, "#6d4f3b");
}
