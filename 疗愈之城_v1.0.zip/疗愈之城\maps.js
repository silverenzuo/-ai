/* 疗愈之城 · 地图与实体数据
   坐标单位：格子。x 向右上，y 向右下（等距投影）。 */

const MAPS = {
  cafe: {
    id: "cafe",
    name: "解忧咖啡馆",
    w: 14,
    h: 11,
    floor: "wood",
    spawn: { x: 11.4, y: 8.7 },
    walls: [
      // 北墙：两段，留出门洞（门偏右）
      { x: 0, y: 0, w: 7.5, d: 1, h: 1.5 },
      { x: 11.5, y: 0, w: 2.5, d: 1, h: 1.5 },
      // 西墙
      { x: 0, y: 1, w: 1, d: 10, h: 1.5 },
      // 南墙（留三段式大门）
      { x: 0, y: 10, w: 3.5, d: 1, h: 1.5 },
      { x: 10.5, y: 10, w: 3.5, d: 1, h: 1.5 },
      // 东墙
      { x: 13, y: 1, w: 1, d: 9, h: 1.5 },
    ],
    floorZones: [
      // 吧台后方设备区的深色地垫
      { x: 1.2, y: 1.1, w: 7.6, d: 0.7, type: "rug3" },
    ],
    props: [
      /* === L形吧台（深木质，贴北墙 + 向南延伸） === */
      // 吧台后段（贴北墙，不锈钢设备柜）
      { type: "backBar", x: 1.1, y: 1.2, w: 7.8, d: 0.9, h: 1 },
      // 咖啡机
      { type: "machine", x: 2.5, y: 1.3, w: 0.9, d: 0.7, h: 0.52, z: 1 },
      // 手冲器具
      { type: "machine", x: 5.2, y: 1.3, w: 0.8, d: 0.6, h: 0.45, z: 1 },
      // 水槽位置（用小方块表示）
      { type: "cupstack", x: 6.8, y: 1.45, w: 0.8, d: 0.5, h: 0.15, z: 1 },
      // 小器具（咖啡罐等）
      { type: "cupstack", x: 1.8, y: 1.55, w: 0.5, d: 0.4, h: 0.12, z: 1 },

      // L形吧台主体（向南延伸）
      { type: "counter", x: 1.1, y: 2.1, w: 8, d: 3.8, h: 0.9 },
      // AI 终端（吧台上，靠右侧）
      { type: "terminal", x: 8.4, y: 4.8, w: 0.9, d: 0.9, h: 1.2, solid: true },

      // 吧台南侧一排绿色软垫圆凳 ×5
      { type: "stool", x: 1.8, y: 6.4, w: 0.55, d: 0.55 },
      { type: "stool", x: 3.2, y: 6.4, w: 0.55, d: 0.55 },
      { type: "stool", x: 4.6, y: 6.4, w: 0.55, d: 0.55 },
      { type: "stool", x: 6.0, y: 6.4, w: 0.55, d: 0.55 },
      { type: "stool", x: 7.4, y: 6.4, w: 0.55, d: 0.55 },

      /* === 左侧角落（书架 + 小方桌 + 椅子） === */
      // 书架（贴西墙，靠北）
      { type: "shelf", x: 1.1, y: 4, w: 0.9, d: 2.8, h: 1.8, solid: true },
      // 小方桌 + 椅子（书架南侧）
      { type: "table", x: 1.3, y: 7.2, w: 1.5, d: 1.5, h: 0.5, solid: true },
      { type: "chair", x: 0.8, y: 8, w: 0.62, d: 0.62, dir: "right" },
      { type: "chair", x: 2.7, y: 8, w: 0.62, d: 0.62, dir: "left" },

      /* === 右侧小桌（窗边，小友坐这里） === */
      { type: "table", x: 10.5, y: 2, w: 1.8, d: 1, h: 0.5, solid: true },
      { type: "chair", x: 9.7, y: 3.1, w: 0.62, d: 0.62, dir: "right" },
      { type: "chair", x: 11.8, y: 3.1, w: 0.62, d: 0.62, dir: "left" },

      /* === 右下角落（猫窝 + 猫 + 食盆） === */
      { type: "catBed", x: 10.5, y: 8, w: 2.5, d: 2.5 },
      { type: "cat", x: 11.3, y: 8.5, w: 0.9, d: 0.6 },
      { type: "floorBowl", x: 9.8, y: 9.5, w: 0.55, d: 0.55 },

      /* === 墙面装饰画 === */
      { type: "wallArt", x: 0.92, y: 6.5, w: 0.7, h: 0.55, z: 0.55 },
      { type: "wallArt", x: 0.92, y: 9.2, w: 0.7, h: 0.55, z: 0.55 },

      /* === 灯具 === */
      { type: "pendant", x: 2.5, y: 4.5, z: 2.9 },
      { type: "pendant", x: 5.5, y: 3.5, z: 2.9 },
      { type: "pendant", x: 11.5, y: 3, z: 2.9 },

      /* === 植物 === */
      { type: "plant", x: 12.6, y: 1.8, w: 0.7, d: 0.7, size: 0.9 },

      /* === 门与门垫 === */
      { type: "door", x: 11.5, y: 0, w: 2.5, d: 0.4, h: 1.45 },
      { type: "mat", x: 11.65, y: 1.05, w: 2.2, d: 0.75 },

      /* === 其他保留 === */
      { type: "paper", x: 5.2, y: 9.5, w: 0.55, d: 0.4 },
    ],
    npcs: [
      { id: "xiaoyou", name: "小友", glyph: "友", x: 10.7, y: 3.9, dir: "up", kid: true },
    ],
    interactables: [
      { id: "door", story: "cafeDoor", x: 12.7, y: 1.2, range: 1.5 },
      { id: "counter", story: "coffee", x: 4.5, y: 4.5, range: 2 },
      { id: "ai", story: "terminal", x: 8.7, y: 4.8, range: 1.5 },
      { id: "cat", story: "cat", x: 11.3, y: 8.8, range: 1.8 },
      { id: "paper", story: "paper", x: 5.2, y: 9.7, range: 1.5 },
    ],
    lights: [
      { x: 2.5, y: 4.5, z: 2.5, r: 190, color: "rgba(255, 210, 150, .24)" },
      { x: 5.5, y: 3.5, z: 2.5, r: 180, color: "rgba(255, 210, 150, .22)" },
      { x: 11.5, y: 3, z: 2.5, r: 160, color: "rgba(255, 210, 150, .2)" },
      { x: 4.5, y: 4.5, z: 1.2, r: 150, color: "rgba(255, 220, 170, .12)" },
    ],
  },

  street: {
    id: "street",
    name: "疗愈之城 · 南街",
    w: 18,
    h: 12,
    floor: "stone",
    spawn: { x: 2.2, y: 3.3 },
    walls: [],
    floorZones: [
      { x: 1, y: 6, w: 16, d: 3, type: "road" },
    ],
    buildings: [
      { x: 0, y: 0, w: 4, d: 2, h: 2.1, sign: "解忧咖啡" },
      { x: 4, y: 0, w: 3, d: 2, h: 2.6, sign: "旧书店" },
      { x: 7, y: 0, w: 3, d: 2, h: 2.3, sign: "花房" },
      { x: 10, y: 0, w: 4, d: 2, h: 2.7, sign: "便利店" },
      { x: 14, y: 0, w: 4, d: 2, h: 2.2, sign: "公寓" },
    ],
    borderWalls: [
      { x: 0, y: 2, w: 1, d: 9, h: 1.5 },
      { x: 17, y: 2, w: 1, d: 9, h: 1.5 },
      { x: 0, y: 11, w: 18, d: 1, h: 0.9, fence: true },
    ],
    props: [
      { type: "cafeFacade", x: 1.2, y: 1.9, w: 1.6, d: 0.35, h: 1.45 },
      { type: "streetlamp", x: 3, y: 5.2, w: 0.5, d: 0.5, solid: true, h: 1.9 },
      { type: "streetlamp", x: 9, y: 5.2, w: 0.5, d: 0.5, solid: true, h: 1.9 },
      { type: "streetlamp", x: 15, y: 5.2, w: 0.5, d: 0.5, solid: true, h: 1.9 },
      { type: "streetlamp", x: 5, y: 9.6, w: 0.5, d: 0.5, solid: true, h: 1.9 },
      { type: "streetlamp", x: 13, y: 9.6, w: 0.5, d: 0.5, solid: true, h: 1.9 },
      { type: "tree", x: 4.2, y: 4, w: 0.9, d: 0.9, solid: true, size: 1 },
      { type: "tree", x: 12.6, y: 4.1, w: 0.9, d: 0.9, solid: true, size: 0.9 },
      { type: "vending", x: 15.3, y: 3.1, w: 1.15, d: 0.9, h: 1.45, solid: true },
      { type: "shelter", x: 3.2, y: 4.9, w: 2.4, d: 0.95, h: 1.35, solid: true },
      { type: "bench", x: 16.2, y: 9.7, w: 2, d: 0.7, h: 0.5, solid: true, dir: "left" },
      { type: "bench", x: 6.4, y: 9.7, w: 2, d: 0.7, h: 0.5, solid: true, dir: "right" },
      { type: "car", x: 11.4, y: 6.9, w: 2.7, d: 1.3, h: 0.85, solid: true },
      { type: "signboard", x: 8.7, y: 2.7, w: 0.8, d: 0.4, h: 0.9 },
      { type: "puddle", x: 6.2, y: 7.7, w: 1.4, d: 0.7 },
      { type: "puddle", x: 14.4, y: 8.3, w: 1.1, d: 0.5 },
    ],
    npcs: [],
    interactables: [
      { id: "streetDoor", story: "streetDoor", x: 2, y: 2.7, range: 1.6, label: "回到咖啡馆" },
    ],
    memories: [
      { id: "candy", glyph: "糖", name: "水果糖", x: 15.2, y: 4.9, tint: "#e8a56e" },
      { id: "umbrella", glyph: "伞", name: "旧雨伞", x: 5.9, y: 6.2, tint: "#8fa9b8" },
      { id: "book", glyph: "书", name: "旧绘本", x: 9.5, y: 3.1, tint: "#95ab8f" },
      { id: "photo", glyph: "照", name: "春游合照", x: 15.8, y: 9.2, tint: "#d8b27a" },
    ],
    lights: [
      { x: 3, y: 5.2, z: 1.9, r: 180, color: "rgba(255, 190, 120, .3)" },
      { x: 9, y: 5.2, z: 1.9, r: 180, color: "rgba(255, 190, 120, .3)" },
      { x: 15, y: 5.2, z: 1.9, r: 180, color: "rgba(255, 190, 120, .3)" },
      { x: 5, y: 9.6, z: 1.9, r: 180, color: "rgba(255, 190, 120, .3)" },
      { x: 13, y: 9.6, z: 1.9, r: 180, color: "rgba(255, 190, 120, .3)" },
      { x: 11.8, y: 0.9, z: 2.1, r: 220, color: "rgba(255, 205, 150, .2)" },
      { x: 5.5, y: 1, z: 2.2, r: 190, color: "rgba(255, 205, 150, .18)" },
    ],
  },
};
