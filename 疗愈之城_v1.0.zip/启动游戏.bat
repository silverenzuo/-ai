@echo off
chcp 65001 >nul
title 疗愈之城 · 本地服务器
echo.
echo   正在启动本地服务器...
echo   浏览器将自动打开 http://127.0.0.1:8766/index.html
echo.
echo   关闭此窗口即可停止服务器。
echo.

cd /d "%~dp0疗愈之城"
start "" http://127.0.0.1:8766/index.html
python -m http.server 8766 --bind 127.0.0.1
pause
