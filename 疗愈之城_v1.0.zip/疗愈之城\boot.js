/* 启动：标题页、角色倾向、继续游戏、初始化。 */

function introDialogue() {
  setTimeout(() => {
    showDialogue(
      "ai",
      "早上好。今日营业状态正常，预计接待十二人。第一位委托人已经在靠窗的位置坐下了。",
      [
        { label: "开始营业", primary: true, action: closeDialogue },
        {
          label: "先看看手记",
          action: () => {
            closeDialogue();
            openPanel("journal");
          },
        },
      ]
    );
    toast("使用 <strong>WASD</strong> 移动，<strong>E</strong> 交互；也可以直接点击地面。");
  }, 650);
}

function startNewGame(origin) {
  const s = defaultState();
  s.started = true;
  s.origin = origin || "empathy";
  s.attrs = { empathy: 2, insight: 2, action: 2 };
  s.attrs[s.origin] += 1;
  G.state = s;
  G.player.dir = "up";
  G.player.moving = false;
  G.titleOpen = false;
  UI.titleScreen.hidden = true;
  UI.origin.hidden = true;
  loadMap("cafe", MAPS.cafe.spawn.x, MAPS.cafe.spawn.y, "up");
  addJournal("今日营业", "上午九点。第一位委托人坐在靠窗的位置，书包放在脚边。");
  saveGame();
  updateHUD();
  introDialogue();
}

function continueGame() {
  const data = loadSave();
  if (!data) {
    toast("没有找到上次的进度。");
    return;
  }
  G.state = data;
  G.player.dir = data.dir || "up";
  G.player.moving = false;
  G.titleOpen = false;
  UI.titleScreen.hidden = true;
  UI.origin.hidden = true;
  const mapId = MAPS[data.map] ? data.map : "cafe";
  const pos = data.pos || MAPS[mapId].spawn;
  loadMap(mapId, pos.x, pos.y, data.dir || "up");
  updateHUD();
  toast(`<strong>继续进度</strong> 第 ${data.phase === "day2" ? 2 : 1} 天 · ${PHASE_TEXT[data.phase] || ""}`);
}

function resetGame() {
  const keep = {
    attrs: { ...G.state.attrs },
    origin: G.state.origin,
    level: G.state.level,
    xp: G.state.xp,
    points: G.state.points,
  };
  const s = defaultState();
  Object.assign(s, keep);
  s.started = true;
  G.state = s;
  G.player.dir = "up";
  G.player.moving = false;
  UI.titleScreen.hidden = true;
  UI.origin.hidden = true;
  G.titleOpen = false;
  loadMap("cafe", MAPS.cafe.spawn.x, MAPS.cafe.spawn.y, "up");
  addJournal("今日营业", "上午九点。第一位委托人坐在靠窗的位置，书包放在脚边。");
  saveGame();
  updateHUD();
  introDialogue();
}

function setupTitle() {
  const btnContinue = $("btnContinue");
  const btnNew = $("btnNew");
  btnContinue.disabled = !hasSave();
  if (hasSave()) {
    const data = loadSave();
    btnContinue.textContent = data.completed ? "继续 · 委托已归档" : "继续上次进度";
  }

  btnNew.addEventListener("click", () => {
    UI.titleScreen.hidden = true;
    UI.origin.hidden = false;
  });

  btnContinue.addEventListener("click", () => {
    if (btnContinue.disabled) return;
    continueGame();
  });

  document.querySelectorAll(".origin-item").forEach((btn) => {
    btn.addEventListener("click", () => startNewGame(btn.dataset.origin));
  });

  UI.titleScreen.hidden = false;
  UI.origin.hidden = true;
}

function initGame() {
  initCanvas();
  bindInput(G.canvas);
  bindUI();
  ensureSaveOnExit();
  setupTitle();
  updateHUD();
  startLoop();
}

initGame();
