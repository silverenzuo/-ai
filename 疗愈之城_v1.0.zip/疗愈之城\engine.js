/* 疗愈之城 · 核心引擎
   等距地图、自由移动、寻路、碰撞、存档。渲染见 render.js，界面见 ui.js，剧情见 story.js。 */

const TW = 64;
const TH = 32;
const ZH = 46;
const SAVE_KEY = "renben-rpg-save-v1";

const ATTR_DEFS = {
  empathy: { name: "共情", desc: "接住别人没说出口的情绪。", glyph: "共" },
  insight: { name: "洞察", desc: "看见关系里被忽略的部分。", glyph: "洞" },
  action: { name: "行动", desc: "把想法变成具体的一步。", glyph: "行" },
};

const LEVEL_XP = [0, 120, 280, 480, 720];

function defaultState() {
  return {
    started: false,
    phase: "day1",
    map: "cafe",
    pos: { x: 11.4, y: 8.7 },
    dir: "up",
    attrs: { empathy: 2, insight: 2, action: 2 },
    origin: null,
    level: 1,
    xp: 0,
    points: 0,
    quality: 0,
    flags: {},
    items: [],
    memories: [],
    journal: [],
    step: 1,
    completed: false,
  };
}

const G = {
  state: defaultState(),
  map: null,
  mapId: "cafe",
  camera: { x: 0, y: 0 },
  canvas: null,
  ctx: null,
  dpr: 1,
  vw: 1280,
  vh: 800,
  player: { x: 11.4, y: 8.7, dir: "up", walk: 0, moving: false },
  path: [],
  onArrive: null,
  keys: new Set(),
  dialogOpen: false,
  panelOpen: false,
  titleOpen: true,
  nearest: null,
  time: 0,
  solids: [],
  interactables: [],
  lastTs: 0,
};

/* ---------------- 存档 ---------------- */

function saveGame() {
  if (!G.state.started) return;
  try {
    const data = { ...G.state, map: G.mapId, pos: { x: G.player.x, y: G.player.y }, dir: G.player.dir };
    localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  } catch (error) {
    /* 本地存储不可用时静默失败 */
  }
}

function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (!data || !data.started) return null;
    return { ...defaultState(), ...data, attrs: { ...defaultState().attrs, ...(data.attrs || {}) } };
  } catch (error) {
    return null;
  }
}

function clearSave() {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch (error) {}
}

function hasSave() {
  return Boolean(loadSave());
}

/* ---------------- 等级 / 属性 ---------------- */

function nextLevelXp() {
  const idx = Math.min(G.state.level, LEVEL_XP.length - 1);
  return LEVEL_XP[idx];
}

function levelProgress() {
  const cur = G.state.level;
  const base = LEVEL_XP[Math.min(cur - 1, LEVEL_XP.length - 1)];
  const next = LEVEL_XP[Math.min(cur, LEVEL_XP.length - 1)];
  if (cur >= LEVEL_XP.length) return { pct: 100, text: "MAX", next };
  const pct = next > base ? Math.max(0, Math.min(1, (G.state.xp - base) / (next - base))) : 1;
  return { pct: pct * 100, text: `${G.state.xp} / ${next}`, next };
}

function addXp(n) {
  const s = G.state;
  s.xp += n;
  let leveled = false;
  while (s.level < LEVEL_XP.length && s.xp >= LEVEL_XP[s.level]) {
    s.level += 1;
    s.points += 1;
    leveled = true;
  }
  updateHUD();
  if (leveled) {
    toast(`<strong>等级提升</strong> Lv.${s.level} · 获得 1 点属性点（按 C 分配）`);
  }
  saveGame();
}

function addQuality(n) {
  G.state.quality += n;
}

/* ---------------- 物品 / 记忆 / 手记 ---------------- */

const ITEM_DB = {
  coffee: { name: "手冲咖啡", glyph: "咖", desc: "温度刚好。也许能让人稍微放松一点。" },
  paper: { name: "旧纸片", glyph: "纸", desc: "被撕掉一角的合照，背面有一行褪色的字。" },
  candy: { name: "水果糖", glyph: "糖", desc: "她分给过你的水果糖。甜的要一起尝。" },
  umbrella: { name: "旧雨伞", glyph: "伞", desc: "一把伞下的两个人，和一场淋湿肩膀的雨。" },
  book: { name: "旧绘本", glyph: "书", desc: "被翻旧的最后一页，她总抢着先念。" },
  photo: { name: "春游合照", glyph: "照", desc: "没有撕掉的那张合照。她其实一直留着。" },
};

function hasItem(id) {
  return G.state.items.includes(id);
}

function giveItem(id) {
  if (hasItem(id)) return false;
  G.state.items.push(id);
  const item = ITEM_DB[id];
  if (item) toast(`<strong>获得物品</strong> ${item.name}`);
  updateHUD();
  saveGame();
  return true;
}

function addMemory(id) {
  const m = (G.map && G.map.memories || []).find((x) => x.id === id);
  if (!m || G.state.memories.includes(id)) return false;
  G.state.memories.push(id);
  giveItem(id);
  return true;
}

function addJournal(title, text) {
  if (G.state.journal.some((j) => j.title === title)) return;
  G.state.journal.push({ title, text });
  updateHUD();
  saveGame();
}

/* ---------------- 地图构建 ---------------- */

function buildSolids(map) {
  const grid = Array.from({ length: map.h }, () => Array(map.w).fill(false));
  const mark = (x, y, w, d) => {
    for (let tx = Math.floor(x); tx < Math.ceil(x + w); tx++) {
      for (let ty = Math.floor(y); ty < Math.ceil(y + d); ty++) {
        if (grid[ty] && tx >= 0 && tx < map.w) grid[ty][tx] = true;
      }
    }
  };
  (map.walls || []).forEach((w) => mark(w.x, w.y, w.w, w.d));
  (map.buildings || []).forEach((b) => mark(b.x, b.y, b.w, b.d));
  (map.borderWalls || []).forEach((b) => mark(b.x, b.y, b.w, b.d));
  (map.props || []).forEach((p) => {
    if (p.solid) mark(p.x, p.y, p.w || 1, p.d || 1);
  });
  return grid;
}

function tileSolid(x, y) {
  const tx = Math.floor(x);
  const ty = Math.floor(y);
  if (!G.map) return true;
  if (tx < 0 || ty < 0 || tx >= G.map.w || ty >= G.map.h) return true;
  return Boolean(G.solids[ty] && G.solids[ty][tx]);
}

function isWalkable(x, y) {
  return !tileSolid(x + 0.001, y + 0.001);
}

function loadMap(id, px, py, dir) {
  const map = MAPS[id];
  if (!map) return;
  G.map = map;
  G.mapId = id;
  G.state.map = id;
  G.solids = buildSolids(map);
  G.interactables = (map.interactables || []).map((it) => ({ ...it }));
  G.path = [];
  G.onArrive = null;
  const p = px != null ? { x: px, y: py } : { x: map.spawn.x, y: map.spawn.y };
  G.player.x = p.x;
  G.player.y = p.y;
  G.player.dir = dir || G.player.dir || "up";
  G.player.walk = 0;
  G.state.pos = { x: p.x, y: p.y };
  snapCamera();
  updateHUD();
}

function snapCamera() {
  const target = cameraTarget();
  G.camera.x = target.x;
  G.camera.y = target.y;
}

function mapBounds() {
  if (!G.map) return { minX: -1000, maxX: 1000, minY: -1000, maxY: 1000 };
  const pts = [
    [0, 0],
    [G.map.w, 0],
    [G.map.w, G.map.h],
    [0, G.map.h],
  ].map(([x, y]) => P(x, y));
  return {
    minX: Math.min(...pts.map((p) => p[0])) - 120,
    maxX: Math.max(...pts.map((p) => p[0])) + 120,
    minY: Math.min(...pts.map((p) => p[1])) - 120,
    maxY: Math.max(...pts.map((p) => p[1])) + 80,
  };
}

function cameraTarget() {
  const [sx, sy] = P(G.player.x, G.player.y);
  const b = mapBounds();
  const halfW = G.vw / 2;
  const halfH = G.vh / 2;
  let cx = sx - halfW;
  let cy = sy - halfH - 40;
  const spanX = b.maxX - b.minX;
  const spanY = b.maxY - b.minY;
  if (spanX <= G.vw) cx = (b.minX + b.maxX) / 2 - halfW;
  else cx = Math.max(b.minX, Math.min(cx, b.maxX - G.vw));
  if (spanY <= G.vh) cy = (b.minY + b.maxY) / 2 - halfH;
  else cy = Math.max(b.minY, Math.min(cy, b.maxY - G.vh));
  return { x: cx, y: cy };
}

function travelTo(id, x, y, dir) {
  const fade = document.getElementById("fade");
  if (fade) fade.classList.add("is-on");
  setTimeout(() => {
    loadMap(id, x, y, dir);
    if (fade) fade.classList.remove("is-on");
    renderStatic();
  }, 360);
}

/* ---------------- 寻路 ---------------- */

function findPath(sx, sy, tx, ty) {
  if (!G.map) return null;
  const start = { x: Math.floor(sx), y: Math.floor(sy) };
  const goal = { x: Math.floor(tx), y: Math.floor(ty) };
  if (!isWalkable(goal.x + 0.5, goal.y + 0.5)) return null;
  const w = G.map.w;
  const h = G.map.h;
  const key = (x, y) => y * w + x;
  const open = [];
  const came = new Map();
  const gScore = new Map();
  const fScore = new Map();
  const startKey = key(start.x, start.y);
  gScore.set(startKey, 0);
  fScore.set(startKey, Math.abs(goal.x - start.x) + Math.abs(goal.y - start.y));
  open.push({ x: start.x, y: start.y, f: fScore.get(startKey) });

  const dirs = [
    [1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1],
    [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414],
  ];

  let guard = 0;
  while (open.length && guard < 6000) {
    guard++;
    let bestIdx = 0;
    for (let i = 1; i < open.length; i++) if (open[i].f < open[bestIdx].f) bestIdx = i;
    const cur = open.splice(bestIdx, 1)[0];
    if (cur.x === goal.x && cur.y === goal.y) {
      const path = [{ x: cur.x, y: cur.y }];
      let ck = key(cur.x, cur.y);
      while (came.has(ck)) {
        const prev = came.get(ck);
        path.unshift(prev);
        ck = key(prev.x, prev.y);
      }
      return path;
    }
    for (const [dx, dy, cost] of dirs) {
      const nx = cur.x + dx;
      const ny = cur.y + dy;
      if (!isWalkable(nx + 0.5, ny + 0.5)) continue;
      if (dx !== 0 && dy !== 0) {
        if (!isWalkable(cur.x + dx + 0.5, cur.y + 0.5) || !isWalkable(cur.x + 0.5, cur.y + dy + 0.5)) continue;
      }
      const nk = key(nx, ny);
      const tentative = (gScore.get(key(cur.x, cur.y)) || 0) + cost;
      if (!gScore.has(nk) || tentative < gScore.get(nk)) {
        came.set(nk, { x: cur.x, y: cur.y });
        gScore.set(nk, tentative);
        const f = tentative + Math.abs(goal.x - nx) + Math.abs(goal.y - ny);
        fScore.set(nk, f);
        const exists = open.find((o) => o.x === nx && o.y === ny);
        if (exists) exists.f = f;
        else open.push({ x: nx, y: ny, f });
      }
    }
  }
  return null;
}

function nearestWalkable(ax, ay, preferNearPlayer = true) {
  let best = null;
  let bestScore = Infinity;
  for (let r = 1; r <= 3; r++) {
    for (let dx = -r; dx <= r; dx++) {
      for (let dy = -r; dy <= r; dy++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const tx = Math.floor(ax) + dx;
        const ty = Math.floor(ay) + dy;
        if (!isWalkable(tx + 0.5, ty + 0.5)) continue;
        const dAnchor = Math.hypot(tx + 0.5 - ax, ty + 0.5 - ay);
        const dPlayer = preferNearPlayer ? Math.hypot(tx + 0.5 - G.player.x, ty + 0.5 - G.player.y) : 0;
        const score = dAnchor * 2 + dPlayer * 0.4;
        if (score < bestScore) {
          bestScore = score;
          best = { x: tx + 0.5, y: ty + 0.5 };
        }
      }
    }
    if (best) return best;
  }
  return best;
}

function walkTo(ax, ay, range, onDone) {
  if (Math.hypot(G.player.x - ax, G.player.y - ay) <= range) {
    onDone();
    return;
  }
  const dest = nearestWalkable(ax, ay);
  if (!dest) {
    toast("那边过不去。");
    return;
  }
  const path = findPath(G.player.x, G.player.y, dest.x, dest.y);
  if (!path || path.length < 2) {
    toast("那边过不去。");
    return;
  }
  G.path = path.slice(1);
  G.onArrive = onDone;
}

function walkToTile(tx, ty) {
  if (!isWalkable(tx + 0.5, ty + 0.5)) return;
  const path = findPath(G.player.x, G.player.y, tx, ty);
  if (!path || path.length < 2) return;
  G.path = path.slice(1);
  G.onArrive = null;
}

/* ---------------- 移动 ---------------- */

function canStand(x, y) {
  const r = 0.26;
  const minX = Math.floor(x - r);
  const maxX = Math.floor(x + r);
  const minY = Math.floor(y - r);
  const maxY = Math.floor(y + r);
  for (let tx = minX; tx <= maxX; tx++) {
    for (let ty = minY; ty <= maxY; ty++) {
      if (tileSolid(tx + 0.5, ty + 0.5)) return false;
    }
  }
  return true;
}

function directionFrom(vx, vy) {
  const sdx = vx - vy;
  const sdy = vx + vy;
  if (Math.abs(sdy) >= Math.abs(sdx) * 0.65) return sdy < 0 ? "up" : "down";
  return sdx < 0 ? "left" : "right";
}

function updateMovement(dt) {
  const p = G.player;
  p.moving = false;
  if (G.dialogOpen || G.panelOpen || G.titleOpen) return;

  // 键盘输入
  let ix = 0;
  let iy = 0;
  if (G.keys.has("left")) ix -= 1;
  if (G.keys.has("right")) ix += 1;
  if (G.keys.has("up")) iy -= 1;
  if (G.keys.has("down")) iy += 1;

  if (ix || iy) {
    G.path = [];
    G.onArrive = null;
    const len = Math.hypot(ix, iy);
    ix /= len;
    iy /= len;
    const sx = ix;
    const sy = iy;
    const vx = (sy / (TH / 2) + sx / (TW / 2)) / 2;
    const vy = (sy / (TH / 2) - sx / (TW / 2)) / 2;
    const vlen = Math.hypot(vx, vy) || 1;
    const speed = 3.1;
    const mx = (vx / vlen) * speed * dt;
    const my = (vy / vlen) * speed * dt;
    p.dir = directionFrom(mx, my);
    if (canStand(p.x + mx, p.y)) p.x += mx;
    if (canStand(p.x, p.y + my)) p.y += my;
    p.walk += dt * 9;
    p.moving = true;
    G.state.pos = { x: p.x, y: p.y };
    return;
  }

  if (!G.path.length) return;

  let target = G.path[0];
  const tx = target.x + 0.5;
  const ty = target.y + 0.5;
  const dx = tx - p.x;
  const dy = ty - p.y;
  const dist = Math.hypot(dx, dy);
  const speed = 3.3 * dt;
  if (dist <= speed + 0.02) {
    p.x = tx;
    p.y = ty;
    G.path.shift();
    if (!G.path.length) {
      const cb = G.onArrive;
      G.onArrive = null;
      if (cb) setTimeout(cb, 60);
      p.moving = false;
      G.state.pos = { x: p.x, y: p.y };
      return;
    }
    target = G.path[0];
  } else {
    const mx = (dx / dist) * speed;
    const my = (dy / dist) * speed;
    p.dir = directionFrom(mx, my);
    p.x += mx;
    p.y += my;
  }
  p.walk += dt * 9;
  p.moving = true;
  G.state.pos = { x: p.x, y: p.y };
}

function setCameraSmooth(dt) {
  if (G.dialogOpen || G.panelOpen || G.titleOpen) {
    const t = cameraTarget();
    const k = 1 - Math.pow(0.001, dt);
    G.camera.x += (t.x - G.camera.x) * Math.min(1, k);
    G.camera.y += (t.y - G.camera.y) * Math.min(1, k);
    return;
  }
  const t = cameraTarget();
  const k = 1 - Math.pow(0.0001, dt);
  G.camera.x += (t.x - G.camera.x) * Math.min(1, k);
  G.camera.y += (t.y - G.camera.y) * Math.min(1, k);
}

/* ---------------- 输入 ---------------- */

function bindInput(canvas) {
  const keyMap = {
    ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right",
    w: "up", s: "down", a: "left", d: "right",
    W: "up", S: "down", A: "left", D: "right",
  };

  window.addEventListener("keydown", (event) => {
    if (event.target && event.target.tagName === "INPUT") return;

    // Tab：终末地风格 HUD 隐藏/显示（优先处理）
    if (event.key === "Tab") {
      event.preventDefault();
      document.body.classList.toggle("hidden-hud");
      const on = document.body.classList.contains("hidden-hud");
      if (typeof toast === "function") toast(`<strong>UI</strong> ${on ? "已隐藏（专注场景）" : "已显示"}`);
      return;
    }

    const mapped = keyMap[event.key];
    if (mapped) {
      // 对话或面板打开时，屏蔽 WASD 移动
      if (G.dialogOpen || G.panelOpen || G.titleOpen) return;
      G.keys.add(mapped);
      event.preventDefault();
      return;
    }
    if (event.key === "e" || event.key === "E" || event.key === " ") {
      if (!G.dialogOpen && !G.panelOpen && !G.titleOpen) {
        event.preventDefault();
        interactNearest();
      }
      return;
    }
    if (event.key === "j" || event.key === "J") { if (!G.titleOpen) openPanel("journal"); return; }
    if (event.key === "c" || event.key === "C") { if (!G.titleOpen) openPanel("char"); return; }
    if (event.key === "i" || event.key === "I") { if (!G.titleOpen) openPanel("bag"); return; }
    if (event.key === "Escape") {
      if (G.panelOpen) closePanel();
      else if (G.dialogOpen) closeDialogue();
    }
  });

  window.addEventListener("keyup", (event) => {
    const mapped = keyMap[event.key];
    if (mapped) G.keys.delete(mapped);
  });

  window.addEventListener("blur", () => G.keys.clear());

  canvas.addEventListener("pointerdown", (event) => {
    if (G.dialogOpen || G.panelOpen || G.titleOpen) return;
    const rect = canvas.getBoundingClientRect();
    const sx = event.clientX - rect.left;
    const sy = event.clientY - rect.top;
    handleCanvasClick(sx, sy);
  });

  const pad = document.getElementById("mobilePad");
  if (pad) {
    pad.querySelectorAll("[data-key]").forEach((btn) => {
      const key = btn.dataset.key;
      const press = (event) => {
        event.preventDefault();
        if (key === "act") {
          if (!G.dialogOpen && !G.panelOpen) interactNearest();
        } else {
          G.keys.add(key);
        }
      };
      const release = (event) => {
        event.preventDefault();
        if (key !== "act") G.keys.delete(key);
      };
      btn.addEventListener("pointerdown", press);
      btn.addEventListener("pointerup", release);
      btn.addEventListener("pointercancel", release);
      btn.addEventListener("pointerleave", release);
    });
  }
}

function handleCanvasClick(sx, sy) {
  const over = clickableAt(sx, sy);
  if (over) {
    walkTo(over.x, over.y, over.range || 1.5, () => runStory(over.story, over));
    return;
  }
  const world = screenToTile(sx, sy);
  if (!world) return;
  walkToTile(Math.floor(world.x), Math.floor(world.y));
}

function screenToTile(sx, sy) {
  const wx = sx + G.camera.x;
  const wy = sy + G.camera.y;
  const a = wx / (TW / 2);
  const b = wy / (TH / 2);
  return { x: (a + b) / 2, y: (b - a) / 2 };
}

function ensureSaveOnExit() {
  window.addEventListener("beforeunload", saveGame);
}
